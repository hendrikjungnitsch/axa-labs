package de.gedoplan.demo.autoconfigdemo;

import de.gedoplan.demo.miniostarter.MinioTemplate;
import jakarta.annotation.PostConstruct;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;

@RequestMapping
@RestController
public class S3Controller
{

    private static final String BUCKET_NAME = "files";

    private final MinioTemplate minioTemplate;

    public S3Controller(MinioTemplate minioTemplate) {
        this.minioTemplate = minioTemplate;
    }

    @GetMapping(value = "/s3/{path}", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getObject(@PathVariable String path) {
        return new String(minioTemplate.download(BUCKET_NAME,path), StandardCharsets.UTF_8);
    }

    @PutMapping(value = "/s3/{path}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public void putObject(@PathVariable String path, @RequestBody String content) {
        minioTemplate.upload(BUCKET_NAME,path,content.getBytes(StandardCharsets.UTF_8));
    }

    @PostConstruct
    public void init() {
        minioTemplate.createBucket(BUCKET_NAME);
    }
}
