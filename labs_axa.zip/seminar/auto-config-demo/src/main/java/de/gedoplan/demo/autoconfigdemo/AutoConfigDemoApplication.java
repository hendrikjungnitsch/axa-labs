package de.gedoplan.demo.autoconfigdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoConfigDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutoConfigDemoApplication.class, args);
    }

}
