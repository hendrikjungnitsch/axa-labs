package de.gedoplan.demo.autoconfigdemo;

import org.springframework.boot.devtools.restart.RestartScope;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.testcontainers.containers.MinIOContainer;

import java.util.List;

@TestConfiguration(proxyBeanMethods = false)
class LocalDevTestcontainersConfig {
    @Bean
    @RestartScope
    @ServiceConnection
    public MinIOContainer mongoDBContainer() {
        MinIOContainer minIOContainer = new MinIOContainer("minio/minio:latest");
        minIOContainer.setPortBindings(List.of("9000:9000","9001:9001"));
        return minIOContainer;
    }
}