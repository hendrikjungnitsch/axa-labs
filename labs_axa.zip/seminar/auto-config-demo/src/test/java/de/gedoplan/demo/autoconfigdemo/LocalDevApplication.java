package de.gedoplan.demo.autoconfigdemo;

import org.springframework.boot.SpringApplication;

public class LocalDevApplication {
    public static void main(String[] args) {
        SpringApplication.from(AutoConfigDemoApplication::main)
          .with(LocalDevTestcontainersConfig.class)
          .run(args);
    }
}