package de.gedoplan.demo.autoconfigdemo.its;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.testcontainers.containers.MinIOContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@Testcontainers
@SpringBootTest
@AutoConfigureMockMvc
class S3IntegrationTest {

    @Container
    @ServiceConnection
    private static final MinIOContainer minioContainer = new MinIOContainer("minio/minio:latest");

    @Autowired
    private MockMvc mockMvc;

    private static final String TEST_JSON = "{\"name\":\"test\"}";

    @Test
    void test() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/s3/{path}","test.json")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(TEST_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());

        mockMvc.perform(MockMvcRequestBuilders.get("/s3/{path}","test.json"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json(TEST_JSON));
    }

}
