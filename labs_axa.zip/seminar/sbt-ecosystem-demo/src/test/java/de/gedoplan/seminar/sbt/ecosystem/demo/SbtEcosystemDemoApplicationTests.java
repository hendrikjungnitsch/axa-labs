package de.gedoplan.seminar.sbt.ecosystem.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtEcosystemDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
