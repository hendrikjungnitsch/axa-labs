package de.gedoplan.seminar.sbt.ecosystem.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtEcosystemDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbtEcosystemDemoApplication.class, args);
    }

}
