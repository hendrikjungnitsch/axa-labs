package de.gedoplan.seminar.sbt.ecosystem.demo.controller;

import de.gedoplan.seminar.sbt.ecosystem.demo.domain.Author;
import de.gedoplan.seminar.sbt.ecosystem.demo.domain.Book;
import de.gedoplan.seminar.sbt.ecosystem.demo.repository.AuthorRepository;
import de.gedoplan.seminar.sbt.ecosystem.demo.repository.BookRepository;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class AuthorController {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public AuthorController(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @QueryMapping
    public List<Author> allAuthors() {
        return authorRepository.findAll();
    }

    @SchemaMapping
    public List<Book> books(Author author) {
        return bookRepository.findByAuthor(author);
    }
}
