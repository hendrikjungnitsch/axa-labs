package de.gedoplan.seminar.sbt.ecosystem.demo.init;

import de.gedoplan.seminar.sbt.ecosystem.demo.domain.Author;
import de.gedoplan.seminar.sbt.ecosystem.demo.domain.Book;
import de.gedoplan.seminar.sbt.ecosystem.demo.repository.AuthorRepository;
import de.gedoplan.seminar.sbt.ecosystem.demo.repository.BookRepository;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.List;

@Component
public class Init {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public Init(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @PostConstruct
    protected void init() {
        List<Author> authors = authorRepository.saveAll(List.of(
                new Author("Irgend", "Jemand"),
                new Author("QL", "Graph")));
        bookRepository.saveAll(List.of(
                new Book("Einführung in GraphQL",100,authors.get(0)),
                new Book("Spring Boot und GraphQL",50,authors.get(0)),
                new Book("Moderne APIs mit GraphQL",160,authors.get(1))));
    }
}
