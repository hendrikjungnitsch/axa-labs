package de.gedoplan.seminar.sbt.actuator.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtActuatorDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
