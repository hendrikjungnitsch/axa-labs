package de.gedoplan.seminar.sbt.actuator.demo.metrics;

import de.gedoplan.seminar.sbt.actuator.demo.repository.PersonRepository;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

@Configuration
public class MetricsConfig {

    @Autowired
    private MeterRegistry meterRegistry;

    @Autowired
    private PersonRepository personRepository;

    @PostConstruct
    private void init() {
        meterRegistry.gauge("persons-count",this,i -> personRepository.count());
    }
}
