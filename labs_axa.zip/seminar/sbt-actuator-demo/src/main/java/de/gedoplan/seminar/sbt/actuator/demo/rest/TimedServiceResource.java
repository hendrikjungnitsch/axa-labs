package de.gedoplan.seminar.sbt.actuator.demo.rest;

import de.gedoplan.seminar.sbt.actuator.demo.service.TimedService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("timedService")
public class TimedServiceResource {

    private final TimedService timedService;

    public TimedServiceResource(TimedService timedService) {
        this.timedService = timedService;
    }

    @GetMapping
    public void callService() {
        timedService.timedMethod();
    }
}
