package de.gedoplan.seminar.sbt.actuator.demo.rest;

import de.gedoplan.seminar.sbt.actuator.demo.domain.Person;
import de.gedoplan.seminar.sbt.actuator.demo.repository.PersonRepository;
import io.micrometer.core.annotation.Timed;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/persons")
public class PersonResource {

    private final PersonRepository personRepository;
    private final MeterRegistry meterRegistry;

    public PersonResource(PersonRepository personRepository, MeterRegistry meterRegistry) {
        this.personRepository = personRepository;
        this.meterRegistry = meterRegistry;
    }


    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Person> getAll() {
        return personRepository.findAll();
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public void createPerson(@RequestBody Person person) {
        meterRegistry.counter("persons-rest-create")
                        .increment();
        personRepository.save(person);
    }

}
