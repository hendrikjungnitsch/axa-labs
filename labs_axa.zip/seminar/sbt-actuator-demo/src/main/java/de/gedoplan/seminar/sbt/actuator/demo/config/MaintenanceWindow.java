package de.gedoplan.seminar.sbt.actuator.demo.config;

import java.time.LocalTime;

import org.springframework.format.annotation.DateTimeFormat;

public record MaintenanceWindow(
    @DateTimeFormat(pattern = "HH:mm") LocalTime from,
    @DateTimeFormat(pattern = "HH:mm") LocalTime till) {
}
