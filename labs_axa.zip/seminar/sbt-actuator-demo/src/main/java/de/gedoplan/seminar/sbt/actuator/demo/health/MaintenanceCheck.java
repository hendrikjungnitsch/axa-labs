package de.gedoplan.seminar.sbt.actuator.demo.health;

import de.gedoplan.seminar.sbt.actuator.demo.config.DemoConfig;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import java.time.LocalTime;

@Component
public class MaintenanceCheck implements HealthIndicator {

    private final DemoConfig demoConfig;

    public MaintenanceCheck(DemoConfig demoConfig) {
        this.demoConfig = demoConfig;
    }

    @Override
    public Health health() {
        LocalTime currentTime = LocalTime.now();
        return demoConfig.maintenanceWindows().stream()
                .anyMatch(mw ->
                        currentTime.isAfter(mw.from()) && currentTime.isBefore(mw.till()))
                ? Health.down().build()
                : Health.up().build();
    }
}

