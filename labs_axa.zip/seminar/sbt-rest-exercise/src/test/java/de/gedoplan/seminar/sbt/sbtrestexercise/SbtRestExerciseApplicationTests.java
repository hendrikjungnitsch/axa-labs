package de.gedoplan.seminar.sbt.sbtrestexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtRestExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
