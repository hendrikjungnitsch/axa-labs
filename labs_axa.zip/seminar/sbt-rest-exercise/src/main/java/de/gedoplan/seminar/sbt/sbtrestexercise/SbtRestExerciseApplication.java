package de.gedoplan.seminar.sbt.sbtrestexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtRestExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbtRestExerciseApplication.class, args);
    }

}
