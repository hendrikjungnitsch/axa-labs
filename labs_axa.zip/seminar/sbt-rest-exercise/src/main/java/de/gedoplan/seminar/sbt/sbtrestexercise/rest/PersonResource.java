package de.gedoplan.seminar.sbt.sbtrestexercise.rest;

import de.gedoplan.seminar.sbt.sbtrestexercise.repository.PersonRepository;

public class PersonResource {
    private final PersonRepository personRepository;

    public PersonResource(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

}
