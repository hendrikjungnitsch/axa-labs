package de.gedoplan.seminar.sbt.sbtrestexercise.repository;

import de.gedoplan.seminar.sbt.sbtrestexercise.domain.Person;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Component
public class PersonRepository {

    private static ConcurrentHashMap<Integer, Person> personen = new ConcurrentHashMap<>();
    private static AtomicInteger nextId = new AtomicInteger(1);

    public PersonRepository() {
        init();
    }


    public void save(Person person) {
        if(Objects.isNull(person.getId())) {
            setId(person,nextId.getAndIncrement());
        }
        personen.put(person.getId(),person);
    }

    public Optional<Person> findById(Integer id) {
        return Optional.ofNullable(personen.get(id));
    }

    public void deleteById(Integer id) {
        personen.remove(id);
    }

    public List<Person> findAll() {
        return personen.values().stream().toList();
    }

    private void setId(Person person, Integer id) {
        Field field = ReflectionUtils.findField(Person.class, "id");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, person, id);
    }

    private void init() {
        Stream.of(new Person("Mustermann", "Max"),
                new Person("Musterfrau", "Erika"))
                .forEach(this::save);
    }
}
