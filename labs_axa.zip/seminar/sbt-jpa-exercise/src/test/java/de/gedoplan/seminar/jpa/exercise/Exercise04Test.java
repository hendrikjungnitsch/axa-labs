package de.gedoplan.seminar.jpa.exercise;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.jayway.jsonpath.JsonPath;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise04Test {

	@Autowired
	MockMvc mockMvc;

	@ParameterizedTest
	@MethodSource("getTestDataJunction")
	void test01_joinJunctionsToHighways(String junctionName, Integer highwayId) throws Exception {
		Integer junctionId = loadJunctionId(junctionName);
		mockMvc.perform(
				put("/junctions/{junctionId}/assignToHighway/{highwayId}",junctionId,highwayId))
				.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("getTestDataJunction")
	void test02_checkHighwayAssignedToJunction(String junctionName, Integer highwayId) throws Exception {
		mockMvc.perform(get("/junctions/loadByName").param("name", junctionName))
				.andExpect(jsonPath("$.highway.id").value(highwayId.toString()));
	}
	
	@ParameterizedTest
	@MethodSource("getTestDataHighway")
	void test03_checkJunctionsAssignedToHighway(Integer highwayId, Integer countJunctions) throws Exception {
		mockMvc.perform(get("/highways/{id}",highwayId))
			.andExpect(jsonPath("$.junctions.size()",is(countJunctions)));
	}
	
	
	private Integer loadJunctionId(String name) throws Exception {
		return JsonPath.parse(mockMvc.perform(get("/junctions/loadByName").param("name", name)).andExpect(status().isOk())
				.andReturn().getResponse().getContentAsString()).read("$.id", Integer.class);
	}
	
	private static Stream<Arguments> getTestDataJunction() {
		return Stream.of(
				arguments("Schwerte", 4610),
				arguments("Westhofener Kreuz", 4610),
				arguments("Hagen-Nord", 4610),
				arguments("Bielefeld-Ost", 4711),
				arguments("Ostwestfalen/Lippe", 4711),
				arguments("Herford/Bad Salzuflen", 4711),
				arguments("Paderborn-Zentrum", 4812));
	}
	
	private static Stream<Arguments> getTestDataHighway() {
		return Stream.of(
				arguments(4610,3),
				arguments(4711,3),
				arguments(4812,1));
	}
}
