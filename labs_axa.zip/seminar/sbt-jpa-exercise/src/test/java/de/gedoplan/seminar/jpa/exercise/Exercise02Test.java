package de.gedoplan.seminar.jpa.exercise;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import de.gedoplan.seminar.jpa.exercise.domain.Junction;
import de.gedoplan.seminar.jpa.exercise.domain.JunctionKind;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise02Test {

	// Sample junctions
	// ... of A1
	private static Junction testJunctionSchwerte = new Junction("Schwerte", JunctionKind.EXIT, "85");
	private static Junction testJunctionKreuzWesthofen = new Junction("Westhofener Kreuz", JunctionKind.INTERCHANGE,
			"86");
	private static Junction testJunctionHagenNord = new Junction("Hagen-Nord", JunctionKind.EXIT, "87");
	// ... of A2
	private static Junction testJunctionHerfordBadSalzuflen = new Junction("Herford/Bad Salzuflen", JunctionKind.EXIT,
			"29");
	private static Junction testJunctionBielefeldOst = new Junction("Bielefeld-Ost", JunctionKind.EXIT, "27");
	private static Junction testJunctionOWL = new Junction("Ostwestfalen/Lippe", JunctionKind.EXIT, "28");
	// ... of A33
	private static Junction testJunctionPaderbornZentrum = new Junction("Paderborn-Zentrum", JunctionKind.EXIT, "17");

	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper mapper;

	@ParameterizedTest
	@MethodSource("getTestJunctions")
	void test01_insert(Junction junction) throws Exception {
		mockMvc.perform(
				post("/junctions").contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(junction)))
				.andExpect(status().isOk());
	}

	private static Stream<Junction> getTestJunctions() {
		return Stream.of(testJunctionSchwerte, testJunctionKreuzWesthofen, testJunctionHagenNord,
				testJunctionHerfordBadSalzuflen, testJunctionBielefeldOst, testJunctionOWL,
				testJunctionPaderbornZentrum);
	}
}
