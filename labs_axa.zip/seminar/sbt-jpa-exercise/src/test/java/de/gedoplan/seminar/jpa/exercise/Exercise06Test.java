package de.gedoplan.seminar.jpa.exercise;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise06Test {
	
	@Autowired
	MockMvc mockMvc;
	
	@Test
	public void test01_findByHighwayId() throws Exception {
		mockMvc.perform(get("/mdeps/findByHighwayName").param("name", "A2"))
			.andExpect(jsonPath("$.size()", is(2)))
			.andExpect(jsonPath("$[*].name", hasItems("Kamen", "Bielefeld")));
	}
	
}
