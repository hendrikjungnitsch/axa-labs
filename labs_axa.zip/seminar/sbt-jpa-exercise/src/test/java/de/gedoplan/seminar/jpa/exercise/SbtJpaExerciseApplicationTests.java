package de.gedoplan.seminar.jpa.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtJpaExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
