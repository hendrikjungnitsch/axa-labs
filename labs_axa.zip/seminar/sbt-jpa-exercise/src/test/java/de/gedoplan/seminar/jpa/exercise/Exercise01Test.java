package de.gedoplan.seminar.jpa.exercise;

import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import de.gedoplan.seminar.jpa.exercise.domain.Highway;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise01Test {

	// Some test data
	private static Highway testHighwayA1_DO_K = new Highway(4610, "A1", "Dortmund", "Cologne");
	private static Highway testHighwayA2_DO_H = new Highway(4711, "A2", "Dortmund", "Hannover");
	private static Highway testHighwayA33_BI_PB = new Highway(4812, "A33", "Bielefeld", "Paderborn");

	@Autowired
	MockMvc mockMvc;
	
	@Autowired 
	private ObjectMapper mapper;

	@ParameterizedTest
	@MethodSource("getTestHighways")
	void test01_insert(Highway highway) throws Exception {
		mockMvc.perform(post("/highways")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(highway)))
			.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("getTestDataFindById")
	void test2_findById(int id, String name) throws Exception {
		mockMvc.perform(get("/highways/{id}",id))
			.andExpect(jsonPath("$.name").value(name));
	}
	
	private static Stream<Highway> getTestHighways() {
		return Stream.of(testHighwayA1_DO_K, testHighwayA2_DO_H,
				testHighwayA33_BI_PB);
	}
	
	private static Stream<Arguments> getTestDataFindById() {
		return Stream.of(
				arguments(4711,"A2"),
				arguments(4812, "A33"));
	}

}
