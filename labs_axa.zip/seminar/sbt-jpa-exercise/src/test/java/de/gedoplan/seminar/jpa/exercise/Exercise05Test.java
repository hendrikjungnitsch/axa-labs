package de.gedoplan.seminar.jpa.exercise;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import de.gedoplan.seminar.jpa.exercise.domain.Highway;
import de.gedoplan.seminar.jpa.exercise.domain.MaintenanceDepartment;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise05Test {

	@Autowired
	MockMvc mockMvc;

	@Autowired
	ObjectMapper objectMapper;

	@ParameterizedTest
	@MethodSource("getTestData")
	public void test01_insert(String maintenanceDepartmentName, List<Integer> highwayIds) throws JsonProcessingException, Exception {
		Highway[] highways = highwayIds.stream().map(this::loadHighway).toArray(Highway[]::new);
		MaintenanceDepartment maintenanceDepartment = new MaintenanceDepartment(maintenanceDepartmentName, highways);
		mockMvc.perform(post("/mdeps")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(maintenanceDepartment)))
			.andExpect(status().isOk());
	}
	
	@Test
	void test02_checkFindAll() throws Exception {
		mockMvc.perform(get("/mdeps"))
			.andExpect(jsonPath("$[?(@.name=='Kamen')].highways.size()",is(List.of(2))))
			.andExpect(jsonPath("$[?(@.name=='Bielefeld')].highways.size()",is(List.of(2))));
	}

	private Highway loadHighway(Integer id) {
		try {
			return objectMapper.readValue(mockMvc.perform(get("/highways/{id}", id)).andExpect(status().isOk())
					.andReturn().getResponse().getContentAsString(), Highway.class);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static Stream<Arguments> getTestData() {
		return Stream.of(arguments("Kamen", List.of(4610, 4711)), arguments("Bielefeld", List.of(4711, 4812)));
	}
}
