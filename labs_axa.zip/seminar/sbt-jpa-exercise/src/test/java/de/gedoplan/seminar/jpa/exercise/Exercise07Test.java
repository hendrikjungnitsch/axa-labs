package de.gedoplan.seminar.jpa.exercise;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

import de.gedoplan.seminar.jpa.exercise.domain.Junction;

@TestMethodOrder(MethodOrderer.MethodName.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Exercise07Test {
	
	private static String MESSAGE_FORMAT = "%s from %s to %s: %d km %s between %s and %s caused by %s\n";

	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private Logger logger;

	
	// Test01 insert
	
	// Test02 output


	private Junction loadJunctionId(String name) throws Exception {
		return mapper.readValue(mockMvc.perform(get("/junctions/loadByName").param("name", name))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), Junction.class);
	}

	private <T> List<T> parse(String json, Class<T> type) {
		CollectionType javaType = mapper.getTypeFactory().constructCollectionType(List.class, type);
		try {
			return mapper.readValue(json, javaType);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

}
