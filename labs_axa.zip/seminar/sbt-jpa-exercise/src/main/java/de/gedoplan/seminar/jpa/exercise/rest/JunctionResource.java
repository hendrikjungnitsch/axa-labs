package de.gedoplan.seminar.jpa.exercise.rest;

import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import de.gedoplan.seminar.jpa.exercise.domain.Junction;
import de.gedoplan.seminar.jpa.exercise.repository.JunctionRepository;

@RestController
@RequestMapping("/junctions")
public class JunctionResource {



  @Autowired
  Logger logger;

  @Autowired
  JunctionRepository junctionRepository;

  /**
   * Exercise JPA_BASICS_02: Insert test data.
   */
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  public void insert(@RequestBody Junction junction) {
    this.logger.debug("----- insert -----");

    this.junctionRepository.save(junction);
    
    this.logger.debug("Inserted: " + junction);
  }
  
  /**
   * Exercise JPA_BASICS_04
   */
  @GetMapping("loadByName")
  public Junction loadByName(@RequestParam("name") String name) {
    this.logger.debug("----- loadByName -----");

    Optional<Junction> junction = this.junctionRepository.readByName(name);
    
    junction.ifPresent(j -> this.logger.debug(name+": "+j));
    return junction.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
  }
  
  @PutMapping("/{junctionId}/assignToHighway/{highwayId}")
  public void assignToHighway(@PathVariable Integer junctionId, @PathVariable Integer highwayId) {
	  
  }
}
