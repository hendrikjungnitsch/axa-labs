package de.gedoplan.seminar.jpa.exercise.repository;

public interface HighwayRepository {

}
