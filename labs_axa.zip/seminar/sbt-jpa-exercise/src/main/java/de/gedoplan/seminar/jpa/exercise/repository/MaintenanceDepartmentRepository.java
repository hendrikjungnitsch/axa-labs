package de.gedoplan.seminar.jpa.exercise.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.exercise.domain.MaintenanceDepartment;

@Repository
public interface MaintenanceDepartmentRepository extends JpaRepository<MaintenanceDepartment, Integer> {

}
