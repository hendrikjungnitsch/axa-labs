package de.gedoplan.seminar.jpa.exercise.domain;

public enum JunctionKind {
  EXIT, INTERCHANGE
}
