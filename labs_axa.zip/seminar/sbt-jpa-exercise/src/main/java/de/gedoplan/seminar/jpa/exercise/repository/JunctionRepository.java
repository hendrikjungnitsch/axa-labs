package de.gedoplan.seminar.jpa.exercise.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.exercise.domain.Junction;

@Repository
public interface JunctionRepository extends JpaRepository<Junction, Integer> {
	
	Optional<Junction> readByName(String name);

}
