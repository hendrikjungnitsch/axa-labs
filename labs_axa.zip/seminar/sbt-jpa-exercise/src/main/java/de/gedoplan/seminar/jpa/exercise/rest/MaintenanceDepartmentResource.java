package de.gedoplan.seminar.jpa.exercise.rest;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import de.gedoplan.seminar.jpa.exercise.domain.MaintenanceDepartment;
import de.gedoplan.seminar.jpa.exercise.repository.MaintenanceDepartmentRepository;

@RequestMapping(path = "/mdeps", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
public class MaintenanceDepartmentResource {

	@Autowired
	Logger logger;

	@Autowired
	MaintenanceDepartmentRepository maintenanceDepartmentRepository;

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public void insert(@RequestBody MaintenanceDepartment maintenanceDepartment) {
		this.logger.debug("----- insert -----");

		this.maintenanceDepartmentRepository.save(maintenanceDepartment);

		this.logger.debug("Inserted: " + maintenanceDepartment);
	}

	/**
	 * Exercise JPA_BASICS_05: Find all entries.
	 */
	@GetMapping
	public List<MaintenanceDepartment> findAll() {
		this.logger.debug("----- findAll -----");

		List<MaintenanceDepartment> maintenanceDepartments = maintenanceDepartmentRepository.findAll();
		this.logger.debug("Gefunden: " + maintenanceDepartments);
		return maintenanceDepartments;
	}

	/**
	 * Exercise JPA_BASICS_06: Find by highway name.
	 */
	@GetMapping("findByHighwayName")
	public List<MaintenanceDepartment> findByHighwayName(@RequestParam("name") String highwayName) {
		this.logger.debug("----- findByHighwayName -----");

		List<MaintenanceDepartment> maintenanceDepartments = List.of(); // this.highwayRepository.
		this.logger.debug(highwayName + ": " + maintenanceDepartments);
		return maintenanceDepartments;
	}

}
