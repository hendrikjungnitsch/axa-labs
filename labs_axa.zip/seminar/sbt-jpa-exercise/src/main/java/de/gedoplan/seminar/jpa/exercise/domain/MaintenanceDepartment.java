package de.gedoplan.seminar.jpa.exercise.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import de.gedoplan.seminar.jpa.exercise.common.GeneratedIntegerIdEntity;

@Entity
@Table(name = MaintenanceDepartment.TABLE_NAME)
public class MaintenanceDepartment extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_MAINTENANCE_DEPT";
  public static final String TABLE_NAME_HIGHWAYS = "JPA_MAINTENANCE_DEPT_HIGHWAY";

  private String name;


  protected MaintenanceDepartment() {
  }

  public MaintenanceDepartment(String name, Highway... highways) {
    this.name = name;
  }

  public String getName() {
    return this.name;
  }
}
