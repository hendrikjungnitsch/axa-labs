package de.gedoplan.seminar.jpa.exercise.domain;

public class Highway {

	private int id;
	private String name;
	private String origin;
	private String destination;

	public Highway(int id, String name, String origin, String destination) {
		this.id = id;
		this.name = name;
		this.origin = origin;
		this.destination = destination;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getName() {
		return this.name;
	}

	public String getOrigin() {
		return this.origin;
	}

	public String getDestination() {
		return this.destination;
	}



}
