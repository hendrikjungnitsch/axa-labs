package de.gedoplan.seminar.jpa.exercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtJpaExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbtJpaExerciseApplication.class, args);
	}

}
