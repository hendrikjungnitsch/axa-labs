package de.gedoplan.seminar.jpa.exercise.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Junction {

	@Id
	private Integer id;

	private String name;

	private JunctionKind kind;

	private String no;

	public Junction(String name, JunctionKind kind, String no) {
		this.name = name;
		this.kind = kind;
		this.no = no;
	}

}
