package de.gedoplan.demo.miniostarter;

import io.minio.MinioClient;
import io.minio.messages.Bucket;
import org.springframework.boot.actuate.autoconfigure.health.ConditionalOnEnabledHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("minio")
@ConditionalOnClass(HealthIndicator.class)
@ConditionalOnEnabledHealthIndicator("minio")
public class MinioHealthIndicator implements HealthIndicator {

    private final MinioClient minioClient;

    public MinioHealthIndicator(MinioClient minioClient) {
        this.minioClient = minioClient;
    }


    @Override
    public Health health() {
        try {
            List<Bucket> buckets = minioClient.listBuckets();
            return Health.up().withDetail("buckets", buckets).build();
        } catch (Exception e) {
            return Health.down(e).build();
        }
    }
}
