package de.gedoplan.demo.miniostarter;

import io.minio.MinioClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@EnableConfigurationProperties(MinioSpringProperties.class)
@Import({MinioTemplate.class, MinioHealthIndicator.class})
public class MinioAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(MinioConnectionDetails.class)
    public MinioConnectionDetails minioConnectionDetails(MinioSpringProperties properties) {
        return new PropertiesMinioConnectionDetails(properties);
    }

    @Bean
    public MinioClient createMinioClient(MinioConnectionDetails minioConnectionDetails) {
        return MinioClient.builder()
                .endpoint(minioConnectionDetails.endpoint())
                .credentials(minioConnectionDetails.accessKey(),
                        minioConnectionDetails.secretKey()).build();
    }
}
