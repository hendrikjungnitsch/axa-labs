package de.gedoplan.demo.miniostarter;

import io.minio.*;
import io.minio.errors.*;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Component
public class MinioTemplate {
    private final MinioClient minioClient;

    public MinioTemplate(MinioClient minioClient) {
        this.minioClient = minioClient;
    }

    public void upload(String bucket, String path, byte[] bytes) {
        try(InputStream bis = new ByteArrayInputStream(bytes)) {
            minioClient.putObject(PutObjectArgs.builder()
                    .bucket(bucket)
                    .object(path)
                    .stream(new ByteArrayInputStream(bytes),bytes.length,-1)
                    .build());
        } catch (Exception e) {
            throw new RuntimeException("Fehler bei Upload nach Minio, Bucket=%s, Path=%s".formatted(bucket,path), e);
        }

    }

    public byte[] download(String bucket, String path) {
        try {
            return minioClient.getObject(GetObjectArgs.builder()
                    .bucket(bucket)
                    .object(path)
                    .build()).readAllBytes();
        } catch (Exception e) {
            throw new RuntimeException("Fehler bei Download von Minio, Bucket=%s, Path=%s".formatted(bucket,path), e);
        }
    }

    public void createBucket(String bucket) {
        try {
            if(minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucket).build())) {
                return;
            }
            minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucket).build());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
