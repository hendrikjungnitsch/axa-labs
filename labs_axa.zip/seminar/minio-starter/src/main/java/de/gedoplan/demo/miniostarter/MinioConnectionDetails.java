package de.gedoplan.demo.miniostarter;

import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;

public interface MinioConnectionDetails extends ConnectionDetails {
    public String endpoint();
    public String accessKey();
    public String secretKey();
}
