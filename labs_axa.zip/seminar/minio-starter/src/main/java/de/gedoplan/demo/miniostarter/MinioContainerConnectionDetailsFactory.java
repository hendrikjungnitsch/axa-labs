package de.gedoplan.demo.miniostarter;

import org.springframework.boot.testcontainers.service.connection.ContainerConnectionDetailsFactory;
import org.springframework.boot.testcontainers.service.connection.ContainerConnectionSource;
import org.testcontainers.containers.MinIOContainer;

public class MinioContainerConnectionDetailsFactory extends ContainerConnectionDetailsFactory<MinIOContainer,MinioConnectionDetails> {

    @Override
    protected MinioConnectionDetails getContainerConnectionDetails(ContainerConnectionSource<MinIOContainer> source) {
        return new MockMinioContainerConnectionDetails(source);
    }

    private static final class MockMinioContainerConnectionDetails extends ContainerConnectionDetailsFactory.ContainerConnectionDetails<MinIOContainer> implements MinioConnectionDetails {
        private MockMinioContainerConnectionDetails(ContainerConnectionSource<MinIOContainer> source) {
            super(source);
        }

        @Override
        public String endpoint() {
            return getContainer().getS3URL();
        }

        @Override
        public String accessKey() {
            return getContainer().getUserName();
        }

        @Override
        public String secretKey() {
            return getContainer().getPassword();
        }
    }
}
