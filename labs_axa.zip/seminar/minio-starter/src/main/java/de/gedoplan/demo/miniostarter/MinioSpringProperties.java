package de.gedoplan.demo.miniostarter;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "minio")
public record MinioSpringProperties(String endpoint, String accessKey, String secretKey) {
}
