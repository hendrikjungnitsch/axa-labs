package de.gedoplan.demo.miniostarter;

public class PropertiesMinioConnectionDetails implements MinioConnectionDetails {

    private final MinioSpringProperties properties;

    public PropertiesMinioConnectionDetails(MinioSpringProperties properties) {
        this.properties = properties;
    }

    @Override
    public String endpoint() {
        return properties.endpoint();
    }

    @Override
    public String accessKey() {
        return properties.accessKey();
    }

    @Override
    public String secretKey() {
        return properties.secretKey();
    }
}
