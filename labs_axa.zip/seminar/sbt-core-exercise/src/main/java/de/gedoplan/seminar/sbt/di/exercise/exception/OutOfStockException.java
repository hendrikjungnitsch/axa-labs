package de.gedoplan.seminar.sbt.di.exercise.exception;

import de.gedoplan.seminar.sbt.di.exercise.domain.Beverage;

public class OutOfStockException extends RuntimeException {
  public OutOfStockException(Beverage cocktailIngredient) {
    super(cocktailIngredient.getName() + " is out of stock");
  }
}
