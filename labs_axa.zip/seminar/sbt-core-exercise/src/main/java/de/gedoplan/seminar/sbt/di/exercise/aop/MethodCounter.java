package de.gedoplan.seminar.sbt.di.exercise.aop;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.Collectors;

@Component
public class MethodCounter {

    private ConcurrentMap<String, LongAdder> methodCounts = new ConcurrentHashMap<>();


    protected void increase(String methodName) {
        methodCounts.computeIfAbsent(methodName,s -> new LongAdder())
                .increment();
    }

    public Map<String,Long> getMethodCounts() {
        return methodCounts.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey,e -> e.getValue().longValue()));

    }
}
