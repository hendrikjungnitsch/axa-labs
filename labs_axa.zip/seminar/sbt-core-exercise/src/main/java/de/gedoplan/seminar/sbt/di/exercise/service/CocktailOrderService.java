package de.gedoplan.seminar.sbt.di.exercise.service;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailOrder;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailOrderRepository;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CocktailOrderService {

  @Autowired
  CocktailOrderRepository cocktailOrderRepository;

  @Autowired
  CocktailRepository cocktailRepository;

  public Integer createNewOrder() {
    CocktailOrder cocktailOrder = new CocktailOrder();
    this.cocktailOrderRepository.save(cocktailOrder);
    this.cocktailOrderRepository.flush();
    return cocktailOrder.getId();
  }

  @Transactional
  public void addCocktail(Integer id, String cocktailId) {
    CocktailOrder cocktailOrder = this.cocktailOrderRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException());
    Cocktail cocktail = cocktailRepository.findById(cocktailId)
            .orElseThrow(() -> new IllegalArgumentException());

    cocktailOrder.addCocktail(cocktailId);
  }

  @Transactional
  public void placeOrder(Integer id) {
    CocktailOrder cocktailOrder = this.cocktailOrderRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException());

    if (!cocktailOrder.isPlaced()) {
      cocktailOrder.place();
    }
  }

  public void cancelOrder(Integer id) {
    this.cocktailOrderRepository.deleteById(id);
  }

}
