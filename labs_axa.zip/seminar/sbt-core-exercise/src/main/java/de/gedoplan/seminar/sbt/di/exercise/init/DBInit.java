package de.gedoplan.seminar.sbt.di.exercise.init;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailSamples;
import de.gedoplan.seminar.sbt.di.exercise.repository.BeverageRepository;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailRepository;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.text.ParseException;
import java.util.List;

import static de.gedoplan.seminar.sbt.di.exercise.domain.CocktailSamples.*;

@Component
public class DBInit {

  private final CocktailRepository cocktailRepository;
  private final BeverageRepository beverageRepository;

  public DBInit(CocktailRepository cocktailRepository, BeverageRepository beverageRepository) {
    this.cocktailRepository = cocktailRepository;
    this.beverageRepository = beverageRepository;
  }

  @PostConstruct
  public void dbInit() throws ParseException {

    beverageRepository.saveAll(CocktailSamples.BEVERAGES);

    cocktailRepository.saveAll(CocktailSamples.COCKTAILS);

    cocktailRepository.saveAll(List.of(Cocktail.builder("3HKS", "3 Holy Kings")
        .ingredient(RUM, 3)
        .ingredient(BRANDY, 2)
        .ingredient(LIMEJUICE, 2)
        .ingredient(HONEY, 2)
        .ingredient(CLOVE, 1)
        .ingredient(PIMENTO, 1)
        .build(),
    Cocktail.builder("ACRM", "Apple Crumple")
        .ingredient(VODKA, 5)
        .ingredient(CARAMELSYRUP, 2)
        .ingredient(CINNAMON, 1)
        .ingredient(LEMONJUICE, 1)
        .ingredient(APPLEJUICE, 10)
        .build(),
    Cocktail.builder("ALTW", "Apple Lemon Twister")
        .ingredient(MINERALWATER, 10)
        .ingredient(APPLEJUICE, 5)
        .ingredient(LIMEJUICE, 5)
        .build(),
   Cocktail.builder("CFRD", "Casual Friday")
        .ingredient(VODKA, 3)
        .ingredient(LIMEJUICE, 2)
        .ingredient(APPLEJUICE, 10)
        .ingredient(GHERKIN, 1)
        .build(),
    Cocktail.builder("EBFR", "Erdbeer Frappé")
        .ingredient(MILK, 10)
        .ingredient(STRAWBERRYPURREE, 2)
        .ingredient(SUGAR, 1)
        .ingredient(VANILLA, 1)
        .build(),
    Cocktail.builder("GINT", "Gin Tonic")
        .ingredient(GIN, 5)
        .ingredient(TONICWATER, 5)
        .build(),
   Cocktail.builder("HLSB", "Hells Bells")
        .ingredient(BATIDA, 4)
        .ingredient(CARAMELSYRUP, 2)
        .ingredient(MILK, 8)
        .ingredient(STRAWBERRYPURREE, 4)
        .build(),
    Cocktail.builder("PKDL", "Pink Dolly")
        .ingredient(VODKA, 4)
        .ingredient(ORANGEJUICE, 8)
        .ingredient(PINEAPPLEJUICE, 4)
        .ingredient(GRENADINE, 1)
        .ingredient(CREAM, 3)
        .ingredient(COCOSYRUP, 0.2)
        .build(),
    Cocktail.builder("WTRZ", "Winterzauber")
        .ingredient(RUM, 1)
        .ingredient(REDWINE, 15)
        .ingredient(CINNAMON, 1)
        .ingredient(SUGAR, 10)
        .ingredient(ORANGEJUICE, 2)
        .ingredient(LIMEJUICE, 0.5)
        .ingredient(APPLEJUICE, 2)
        .build()));

  }
}
