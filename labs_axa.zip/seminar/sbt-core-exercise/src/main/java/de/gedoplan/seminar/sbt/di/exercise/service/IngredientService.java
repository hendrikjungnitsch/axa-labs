package de.gedoplan.seminar.sbt.di.exercise.service;

import de.gedoplan.seminar.sbt.di.exercise.domain.Beverage;
import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.exception.OutOfStockException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static java.util.function.Predicate.not;

@Component
public class IngredientService {

  public List<Beverage> beveragesNotAvailable(Cocktail cocktail) {
    return cocktail.getIngredients().entrySet().stream()
            .filter(not(e -> isAvailable(e.getKey(), e.getValue())))
            .map(Map.Entry::getKey)
            .toList();
  }

  public boolean isAvailable(Beverage beverage, double amount) {
    // Dummy check: Anything but rum is available
    return !"RUM".equals(beverage.getId());
  }
}
