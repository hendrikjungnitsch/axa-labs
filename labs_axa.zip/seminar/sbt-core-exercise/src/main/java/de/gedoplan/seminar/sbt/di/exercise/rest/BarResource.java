package de.gedoplan.seminar.sbt.di.exercise.rest;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("bar")
public class BarResource {

    @GetMapping(path = "name", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getName() {
        return null;
    }

    @GetMapping(path = "cocktails", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Cocktail> getCocktails() {
        return List.of();
    }


    @GetMapping(path = "alc", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Cocktail> getAlcoholicCocktails() {
        return List.of();
    }

    @GetMapping(path = "nonalc", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Cocktail> getNonAlcoholicCocktails() {
        return List.of();
    }
}
