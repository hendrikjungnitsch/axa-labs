package de.gedoplan.seminar.sbt.di.exercise.domain;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Access(AccessType.FIELD)
@Table(name = Beverage.TABLE_NAME)
public class Beverage {
  public static final String TABLE_NAME = "DI_BEVERAGE";

  @Id
  private String id;

  private String name;

  private double alcoholPercent;

  public Beverage(String id, String name, double alcoholPercent) {
    this.id = id;
    this.name = name;
    this.alcoholPercent = alcoholPercent;
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return this.name;
  }

  public double getAlcoholPercent() {
    return this.alcoholPercent;
  }

  protected Beverage() {
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Beverage beverage = (Beverage) o;
    return id.equals(beverage.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    return "Beverage{" +
            "id='" + id + '\'' +
            ", name='" + name + '\'' +
            ", alcoholPercent=" + alcoholPercent +
            '}';
  }
}
