package de.gedoplan.seminar.sbt.di.exercise.repository;

import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CocktailOrderRepository extends JpaRepository<CocktailOrder, Integer> {
}
