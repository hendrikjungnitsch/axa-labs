package de.gedoplan.seminar.sbt.di.exercise.domain;

import jakarta.persistence.*;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

@Entity
@Access(AccessType.FIELD)
@Table(name = CocktailOrder.TABLE_NAME)
public class CocktailOrder {
  public static final String TABLE_NAME = "DI_COCKTAIL_ORDER";
  public static final String TABLE_NAME_ORDER_DETAILS = "DI_COCKTAIL_ORDER_DETAILS";

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "ORDER_DATE")
  private Date orderDate;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = CocktailOrder.TABLE_NAME_ORDER_DETAILS, joinColumns = @JoinColumn(name = "ID"))
  @MapKeyColumn(name = "COCKTAIL_ID")
  @Column(name = "COCKTAIL_COUNT")
  private Map<String, Integer> orderDetails = new TreeMap<>();

  public Integer getId() {
    return id;
  }

  public Date getOrderDate() {
    return this.orderDate;
  }

  public Map<String, Integer> getOrderDetails() {
    return Collections.unmodifiableMap(this.orderDetails);
  }

  public boolean isPlaced() {
    return this.orderDate != null;
  }

  public void place() {
    if (!isPlaced()) {
      this.orderDate = new Date();
    }
  }

  public void addCocktail(String cocktailId) {
    if (isPlaced()) {
      throw new IllegalStateException("Placed order may not be changed");
    }

    this.orderDetails.merge(cocktailId, 1, (a, b) -> a + b);
  }

}
