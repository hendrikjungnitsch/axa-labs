package de.gedoplan.seminar.sbt.di.exercise.domain;

import java.util.Arrays;
import java.util.List;

public final class CocktailSamples {
  public static final Beverage PINEAPPLEJUICE = new Beverage("ANANAS", "Pineapple juice", 0.0);
  public static final Beverage APPLEJUICE = new Beverage("ASAFT", "Apple juice", 0.0);
  public static final Beverage BATIDA = new Beverage("BDC", "Batida de Coco", 25.0);
  public static final Beverage BRANDY = new Beverage("BRNDY", "Brandy", 45.0);
  public static final Beverage CASSIS = new Beverage("CASS", "Creme de Cassis", 15);
  public static final Beverage STRAWBERRY = new Beverage("ERDB", "Strawberries", 0);
  public static final Beverage STRAWBERRYPURREE = new Beverage("EBP", "Strawberry purree", 0.0);
  public static final Beverage STRAWBERRYSYRUP = new Beverage("EBS", "Strawberry syrup", 0);
  public static final Beverage GIN = new Beverage("GIN", "Gin", 40.0);
  public static final Beverage GINGERALE = new Beverage("GALE", "Ginger ale", 0);
  public static final Beverage GRENADINE = new Beverage("GNDN", "Grenadine", 0.0);
  public static final Beverage GHERKIN = new Beverage("GURKE", "Gherkin", 0.0);
  public static final Beverage HONEY = new Beverage("HONIG", "Honey", 0.0);
  public static final Beverage CARAMELSYRUP = new Beverage("KARAMEL", "Caramel syrup", 0.0);
  public static final Beverage COCOSYRUP = new Beverage("KOKOS", "Coco syrup", 0.0);
  public static final Beverage LIMEJUICE = new Beverage("LIME", "Lime juice", 0.0);
  public static final Beverage MARACUJAJUICE = new Beverage("MARA", "Maracuja juice", 0);
  public static final Beverage MILK = new Beverage("MILCH", "Milk", 0.0);
  public static final Beverage MINERALWATER = new Beverage("MWAS", "Mineral water", 0.0);
  public static final Beverage CLOVE = new Beverage("NELKE", "Clove", 0.0);
  public static final Beverage ORANGEJUICE = new Beverage("OSAFT", "Orange juice", 0.0);
  public static final Beverage PEACHMARK = new Beverage("PMARK", "Peach mark", 0);
  public static final Beverage PIMENTO = new Beverage("PIMENT", "Pimento", 0.0);
  public static final Beverage CANESUGAR = new Beverage("RZUC", "Cane sugar", 0);
  public static final Beverage REDWINE = new Beverage("RWEIN", "Red wine", 10.0);
  public static final Beverage RUM = new Beverage("RUM", "Rum", 40.0);
  public static final Beverage CHAMPAGNE = new Beverage("SEKT", "Champagne", 11.5);
  public static final Beverage TONICWATER = new Beverage("TONIC", "Tonic water", 0.0);
  public static final Beverage CREAM = new Beverage("SAHNE", "Cream", 0.0);
  public static final Beverage VODKA = new Beverage("WODKA", "Vodka", 37.0);
  public static final Beverage LEMONJUICE = new Beverage("ZSAFT", "Lemon juice", 0.0);
  public static final Beverage VANILLA = new Beverage("VANILLE", "Vanilla", 0.0);
  public static final Beverage CINNAMON = new Beverage("ZIMT", "Cinnamon", 0.0);
  public static final Beverage SUGAR = new Beverage("ZUCKER", "Sugar", 0.0);

  public static final List<Beverage> BEVERAGES = Arrays.asList(PINEAPPLEJUICE, APPLEJUICE, BATIDA, BRANDY, CASSIS, STRAWBERRY, STRAWBERRYPURREE, STRAWBERRYSYRUP, GIN, GINGERALE, GRENADINE, GHERKIN,
      HONEY, CARAMELSYRUP, COCOSYRUP, LIMEJUICE, MARACUJAJUICE, MILK, MINERALWATER, CLOVE, ORANGEJUICE, PEACHMARK, PIMENTO, CANESUGAR, REDWINE, RUM, CHAMPAGNE, TONICWATER, CREAM, VODKA, LEMONJUICE,
      VANILLA, CINNAMON, SUGAR);

  public static final Cocktail BELLINI = Cocktail.builder("bell", "Bellini")
      .ingredient(CHAMPAGNE, 10)
      .ingredient(PEACHMARK, 3)
      .build();
  public static final Cocktail IPANEMA = Cocktail.builder("ipan", "Ipanema")
      .ingredient(GINGERALE, 10)
      .ingredient(LIMEJUICE, 1)
      .ingredient(CANESUGAR, 2)
      .ingredient(MARACUJAJUICE, 2)
      .build();
  public static final Cocktail kirRoyal = Cocktail.builder("kirr", "Kir Royal")
      .ingredient(CHAMPAGNE, 10)
      .ingredient(CASSIS, 1)
      .build();
  public static final Cocktail strawberryDaiquiri = Cocktail.builder("stdq", "Strawberry Daiquiri")
      .ingredient(RUM, 4)
      .ingredient(STRAWBERRY, 5)
      .ingredient(STRAWBERRYSYRUP, 3)
      .ingredient(LEMONJUICE, 1)
      .build();

  public static final List<Cocktail> COCKTAILS = Arrays.asList(BELLINI, IPANEMA, kirRoyal, strawberryDaiquiri);

  public static List<Cocktail> findAll() {
    return COCKTAILS;
  }

  public static Cocktail findById(String id) {
    return COCKTAILS
        .stream()
        .filter(c -> c.getId().equals(id))
        .findFirst()
        .orElse(null);
  }

  private CocktailSamples() {
  }
}
