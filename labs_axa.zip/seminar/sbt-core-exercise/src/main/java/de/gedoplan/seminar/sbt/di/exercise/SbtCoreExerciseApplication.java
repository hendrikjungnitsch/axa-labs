package de.gedoplan.seminar.sbt.di.exercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtCoreExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbtCoreExerciseApplication.class, args);
    }

}
