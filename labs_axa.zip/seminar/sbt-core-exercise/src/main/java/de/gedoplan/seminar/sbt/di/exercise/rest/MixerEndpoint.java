package de.gedoplan.seminar.sbt.di.exercise.rest;

import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailOrder;
import de.gedoplan.seminar.sbt.di.exercise.exception.OutOfStockException;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailOrderRepository;
import de.gedoplan.seminar.sbt.di.exercise.service.CocktailOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@RequestMapping(path = "mixer", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
public class MixerEndpoint {

  @Autowired
  CocktailOrderService cocktailOrderService;

  @Autowired
  CocktailOrderRepository cocktailOrderRepository;


  @PostMapping(path = "order",produces = MediaType.TEXT_PLAIN_VALUE)
  public ResponseEntity<String> postOrder(UriComponentsBuilder uriComponentsBuilder) {
    Integer newId = this.cocktailOrderService.createNewOrder();
    return ResponseEntity
        .created(uriComponentsBuilder
                .pathSegment("api","mixer","order", newId.toString())
                .build().toUri())
        .build();
  }

  @GetMapping(value = "order/{id}")
  public CocktailOrder getOrder(@PathVariable Integer id) {
    return this.cocktailOrderRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
  }

  @PostMapping(path = "order/{id}/{cocktailId}", produces = MediaType.TEXT_PLAIN_VALUE)
  public ResponseEntity<String> addCocktail(@PathVariable Integer id, @PathVariable String cocktailId) {
    try {
      this.cocktailOrderService.addCocktail(id, cocktailId);

      return ResponseEntity
          .status(HttpStatus.CREATED)
          .build();
    } catch (IllegalArgumentException e) {
      return ResponseEntity
          .notFound()
          .build();
    } catch (OutOfStockException e) {
      return ResponseEntity
              .status(HttpStatus.CONFLICT)
          .body(e.getMessage());
    }
  }


  @PutMapping("order/{id}/placed")
  public ResponseEntity<String> setPlaced(@PathVariable Integer id) {
    try {
      this.cocktailOrderService.placeOrder(id);

      return ResponseEntity.noContent().build();
    } catch (IllegalArgumentException e) {
      return ResponseEntity
          .notFound()
          .build();
    }

  }


  @DeleteMapping("order/{id}")
  public void delete(@PathVariable Integer id) {
    this.cocktailOrderService.cancelOrder(id);
  }
}
