package de.gedoplan.seminar.sbt.di.exercise.service;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;

import java.util.List;

public interface CocktailService {

    public List<Cocktail> findAll();
}

