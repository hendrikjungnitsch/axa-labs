package de.gedoplan.seminar.sbt.di.exercise.domain;

import jakarta.persistence.*;
import java.text.Collator;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

@Entity
@Access(AccessType.FIELD)
@Table(name = Cocktail.TABLE_NAME)
public class Cocktail implements Comparable<Cocktail> {
  public static final String TABLE_NAME = "DI_COCKTAIL";
  public static final String TABLE_NAME_INGREDIENTS = "DI_COCKTAIL_INGREDIENT";

  public static final Comparator<Cocktail> NAME_COMPARATOR = new Comparator<Cocktail>() {
    @Override
    public int compare(Cocktail o1, Cocktail o2) {
      return Collator.getInstance().compare(o1.getName(), o2.getName());
    }
  };

  public static final Comparator<Cocktail> BASE_COMPARATOR = new Comparator<Cocktail>() {
    @Override
    public int compare(Cocktail o1, Cocktail o2) {
      String n1 = o1.getBase() != null ? o1.getBase().getName() : "";
      String n2 = o2.getBase() != null ? o2.getBase().getName() : "";
      return Collator.getInstance().compare(n1, n2);
    }
  };

  @Id
  private String id;

  private String name;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = TABLE_NAME_INGREDIENTS)
  @MapKeyJoinColumn(name = "BEVERAGE_ID")
  @Column(name = "AMOUNT")
  private Map<Beverage, Double> ingredients;

  @ManyToOne
  private Beverage base;

  public static CocktailBuilder builder(String id, String name) {
    return new CocktailBuilder(id, name);
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return this.name;
  }

  public Beverage getBase() {
    return this.base;
  }

  public Map<Beverage, Double> getIngredients() {
    return Collections.unmodifiableMap(this.ingredients);
  }

  public boolean isAlcoholic() {
    for (Beverage zutat : this.ingredients.keySet()) {
      if (zutat.getAlcoholPercent() != 0) {
        return true;
      }
    }
    return false;
  }

  protected Cocktail() {
  }

  @Override
  public int compareTo(Cocktail o) {
    return NAME_COMPARATOR.compare(this, o);
  }

  private Cocktail(String id, String name) {
    this.id = id;
    this.name = name;

    this.ingredients = new HashMap<>();
  }

  public static class CocktailBuilder {
    private Cocktail cocktail;

    public CocktailBuilder(String id, String name) {
      this.cocktail = new Cocktail(id, name);
    }

    public CocktailBuilder ingredient(Beverage beverage, double amount) {
      if (this.cocktail.base == null) {
        this.cocktail.base = beverage;
      }

      this.cocktail.ingredients.put(beverage, amount);

      return this;
    }

    public Cocktail build() {
      return this.cocktail;
    }
  }
}
