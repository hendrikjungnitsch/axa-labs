package de.gedoplan.seminar.sbt.di.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtDiExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
