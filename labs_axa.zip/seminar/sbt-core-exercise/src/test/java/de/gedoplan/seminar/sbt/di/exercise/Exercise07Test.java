package de.gedoplan.seminar.sbt.di.exercise;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailSamples;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.function.Predicate;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@AutoConfigureMockMvc
@SpringBootTest
public class Exercise07Test {

    @Autowired
    List<Cocktail> cocktails;

    @Autowired
    private List<Predicate<Cocktail>> filters;

    @Autowired
    MockMvc mockMvc;

    @Test
    public void testFiltersFound() throws Exception {
        Assertions.assertThat(filters).hasSize(2);
    }

    @Test
    public void testFiltersNonAlcEmpty() throws Exception {
        mockMvc.perform(get("/api/bar/nonalc"))
                .andExpect(jsonPath("$.size()",is(0)));
    }

    @Test
    public void testFiltersAlc() throws Exception {
        mockMvc.perform(get("/api/bar/alc"))
                .andExpect(jsonPath("$.size()",is(9)));
    }

}
