package de.gedoplan.seminar.sbt.di.exercise;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailSamples;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@AutoConfigureMockMvc
@SpringBootTest
public class Exercise06Test {

    @Autowired
    List<Cocktail> cocktails;

    @Autowired
    private CocktailRepository cocktailRepository;

    @Autowired
    MockMvc mockMvc;

    @Test
    public void testAlcoholic() throws Exception {
        mockMvc.perform(get("/api/bar/alc"))
                .andExpect(jsonPath("$.size()",is(10)));

        cocktailRepository.save(Cocktail.builder("RUM","Rum")
                .ingredient(CocktailSamples.RUM,0.5d).build());

        mockMvc.perform(get("/api/bar/alc"))
                .andExpect(jsonPath("$.size()",is(11)));
    }

    @Test
    public void testNonAlcoholic() throws Exception {
        mockMvc.perform(get("/api/bar/nonalc"))
                .andExpect(jsonPath("$.size()",is(3)));

        cocktailRepository.save(Cocktail.builder("WATER","Water")
                .ingredient(CocktailSamples.MINERALWATER,0.5d).build());

        mockMvc.perform(get("/api/bar/nonalc"))
                .andExpect(jsonPath("$.size()",is(4)));
    }
}
