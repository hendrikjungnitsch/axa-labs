package de.gedoplan.seminar.sbt.di.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
public class Exercise09Test {
    @Autowired
    MockMvc mockMvc;
    @Test
    public void testMethodCounter() throws Exception {
        mockMvc.perform(get("/api/bar/cocktails"))
                .andExpect(status().isOk());


        mockMvc.perform(get("/api/methodCount"))
                .andExpect(jsonPath("$.getCocktails").value(1));

        mockMvc.perform(get("/api/bar/cocktails"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/methodCount"))
                .andExpect(jsonPath("$.getCocktails").value(2));
    }

}
