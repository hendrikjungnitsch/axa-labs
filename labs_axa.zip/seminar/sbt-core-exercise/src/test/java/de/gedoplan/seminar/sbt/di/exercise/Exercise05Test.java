package de.gedoplan.seminar.sbt.di.exercise;

import de.gedoplan.seminar.sbt.di.exercise.domain.Cocktail;
import de.gedoplan.seminar.sbt.di.exercise.domain.CocktailSamples;
import de.gedoplan.seminar.sbt.di.exercise.repository.CocktailRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@AutoConfigureMockMvc
@SpringBootTest
public class Exercise05Test {

    @Autowired
    List<Cocktail> cocktails;

    @Autowired
    private CocktailRepository cocktailRepository;

    @Autowired
    MockMvc mockMvc;

    @Test
    public void test() throws Exception {
        mockMvc.perform(get("/api/bar/cocktails"))
                .andExpect(jsonPath("$.size()",is(13)));
        cocktailRepository.save(Cocktail.builder("WATER","Water")
                .ingredient(CocktailSamples.MINERALWATER,0.5d).build());
        mockMvc.perform(get("/api/bar/cocktails"))
                .andExpect(jsonPath("$.size()",is(14)));
    }
}
