package de.gedoplan.seminar.sbt.di.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@SpringBootTest
public class Exercise10Test {

    @Autowired
    MockMvc mockMvc;

    @Test
    public void test() throws Exception {
        String location = mockMvc.perform(post("/api/mixer/order"))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getHeader("Location");

        mockMvc.perform(post(location+"/kirr"))
                .andExpect(status().isCreated());

        mockMvc.perform(post(location+"/stdq"))
                .andExpect(status().isConflict());

        mockMvc.perform(put(location+"/placed"))
                .andExpect(status().isNoContent());
    }
}
