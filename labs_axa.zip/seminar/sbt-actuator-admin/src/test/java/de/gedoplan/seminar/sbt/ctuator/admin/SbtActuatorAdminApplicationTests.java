package de.gedoplan.seminar.sbt.ctuator.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtActuatorAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
