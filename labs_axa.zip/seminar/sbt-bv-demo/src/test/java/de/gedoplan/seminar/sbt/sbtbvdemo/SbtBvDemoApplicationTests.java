package de.gedoplan.seminar.sbt.sbtbvdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtBvDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
