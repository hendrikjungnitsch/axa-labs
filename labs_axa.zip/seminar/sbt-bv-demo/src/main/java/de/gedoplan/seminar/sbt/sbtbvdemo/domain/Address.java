package de.gedoplan.seminar.sbt.sbtbvdemo.domain;

import de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint.ValidAddress;
import de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint.ValidZipCode;

import jakarta.validation.constraints.Size;
import java.io.Serializable;

@ValidAddress
public class Address implements Serializable {
  
  @Size(min = 1 )
  private String street;

  @ValidZipCode
  private String zipCode;

  @Size(min = 1 )
  private String city;

  public String getStreet() {
    return this.street;
  }

  public void setStreet(String street) {
    this.street = street;
  }

  public String getZipCode() {
    return this.zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public String getCity() {
    return this.city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  @Override
  public String toString() {
    return "Adresse [strasse=" + this.street + ", plz=" + this.zipCode + ", ort=" + this.city + "]";
  }
}
