package de.gedoplan.seminar.sbt.sbtbvdemo.rest;

import de.gedoplan.seminar.sbt.sbtbvdemo.domain.Questionnaire;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping(path = "/questionnaire", consumes = MediaType.APPLICATION_JSON_VALUE)
public class QuestionnaireResource {

    @PostMapping
    public void postQuestionnaire(@RequestBody @Valid Questionnaire questionnaire) {
        System.out.println(questionnaire);
    }
}
