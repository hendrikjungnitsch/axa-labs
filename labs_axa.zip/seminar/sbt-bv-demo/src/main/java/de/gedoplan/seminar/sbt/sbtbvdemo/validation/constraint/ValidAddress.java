package de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint;

// CHECKSTYLE:OFF

import de.gedoplan.seminar.sbt.sbtbvdemo.validation.validator.AddressValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * BV Constraint for Address.
 *
 */
@Constraint(validatedBy = AddressValidator.class)
@Target({ FIELD, METHOD, TYPE })
@Retention(RUNTIME)
public @interface ValidAddress {
  String message() default "{de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint.ValidAddress.message}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
