package de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint;

// CHECKSTYLE:OFF

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import jakarta.validation.ReportAsSingleViolation;
import jakarta.validation.constraints.Pattern;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * BV Constraint für ZIP codes.
 *
 */
@Constraint(validatedBy = {})
@Pattern(regexp = "\\d{5}")
@ReportAsSingleViolation
@Target({ FIELD, METHOD })
@Retention(RUNTIME)
public @interface ValidZipCode {
  String message() default "{de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint.ValidZipCode.message}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
