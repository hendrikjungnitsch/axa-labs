package de.gedoplan.seminar.sbt.sbtbvdemo.validation.validator;

import de.gedoplan.seminar.sbt.sbtbvdemo.domain.Address;
import de.gedoplan.seminar.sbt.sbtbvdemo.validation.constraint.ValidAddress;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * BV Validator for constraint {@link ValidAddress}.
 * Addresses are valid, if their components are completely <code>null</code> or not <code>null</code>.
 *
 */
public class AddressValidator implements ConstraintValidator<ValidAddress, Address> {
  @Override
  public void initialize(ValidAddress constraint) {
  }

  @Override
  public boolean isValid(Address adresse, ConstraintValidatorContext validationContext) {
    // null is ok
    if (adresse == null) {
      return true;
    }

    // every attribute null is ok
    if (adresse.getCity() == null && adresse.getZipCode() == null && adresse.getStreet() == null) {
      return true;
    }

    // For demo of generating individual messages: If ZIP code is "00000" ...
    if ("00000".equals(adresse.getZipCode())) {
      // ... disable default message
      validationContext.disableDefaultConstraintViolation();

      // ... add message for validated object
      validationContext.buildConstraintViolationWithTemplate("{de.gedoplan.seminar.bv.demo.validation.constraint.ValidAddress.message}")
          .addConstraintViolation();

      // ... and/or add message for path within object
      validationContext.buildConstraintViolationWithTemplate("{de.gedoplan.seminar.bv.demo.validation.constraint.ValidZipCode.message}")
          .addPropertyNode("zipCode")
          .addConstraintViolation();

      return false;
    }

    // every attribute filled is ok
    return adresse.getCity() != null && adresse.getZipCode() != null && adresse.getStreet() != null;
  }
}
