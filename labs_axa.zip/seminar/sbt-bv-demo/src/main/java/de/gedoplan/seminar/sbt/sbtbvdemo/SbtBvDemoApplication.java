package de.gedoplan.seminar.sbt.sbtbvdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtBvDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbtBvDemoApplication.class, args);
    }

}
