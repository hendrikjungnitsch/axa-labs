package de.gedoplan.seminar.sbt.sbtbvdemo.domain;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Questionnaire implements Serializable {

  private Integer id;

  @NotNull
  @Past
  private LocalDate pollDate;

  @NotNull
  @Size(min = 1)
  private String name;

  @Valid
  private Address address = new Address();

  @Min(value = 18)
  @Max(value = 120)
  private int age;

  @Pattern(regexp = "[^@]+@[^@]+\\.[^@]+")
  private String email;

  @NotNull
  @Size(min = 10, max = 140)
  private String comment;

  public LocalDate getPollDate() {
    return this.pollDate;
  }

  public void setPollDate(LocalDate pollDate) {
    this.pollDate = pollDate;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Address getAddress() {
    return this.address;
  }

  public int getAge() {
    return this.age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public String getEmail() {
    return this.email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getComment() {
    return this.comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public Integer getId() {
    return this.id;
  }

  @Override
  public boolean equals(Object other) {
    if (this == other)
      return true;
    if (other == null || getClass() != other.getClass())
      return false;
    Questionnaire that = (Questionnaire) other;
    return Objects.equals(id, that.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    return "Fragebogen [id=" + this.id + ", pollDate=" + this.pollDate + ", name=" + this.name + ", adresse=" + this.address + ", age=" + this.age + ", email=" + this.email + ", comment="
        + this.comment + "]";
  }

}
