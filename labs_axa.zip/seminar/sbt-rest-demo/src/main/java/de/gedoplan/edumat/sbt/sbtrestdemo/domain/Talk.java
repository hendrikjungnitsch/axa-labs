package de.gedoplan.edumat.sbt.sbtrestdemo.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Talk {

  private Integer id;

  private String title;

  private List<String> speakers;

  private TalkType talkType;
  private LocalDateTime start;

  private Integer duration;

  public Talk(String title, TalkType talkType, LocalDateTime start, int duration, String... speakers) {
    this.title = title;
    this.talkType = talkType;
    this.start = start;
    this.duration = duration;
    this.speakers = new ArrayList<>();
    Collections.addAll(this.speakers, speakers);
  }

  protected Talk() {
  }

  public String getTitle() {
    return this.title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public List<String> getSpeakers() {
    return this.speakers;
  }

  public void setSpeakers(List<String> speakers) {
    this.speakers = speakers;
  }

  public TalkType getTalkType() {
    return this.talkType;
  }

  public void setTalkType(TalkType talkType) {
    this.talkType = talkType;
  }

  public LocalDateTime getStart() {
    return this.start;
  }

  public void setStart(LocalDateTime start) {
    this.start = start;
  }

  public Integer getDuration() {
    return this.duration;
  }

  public void setDuration(Integer duration) {
    this.duration = duration;
  }

  public Integer getId() {
    return id;
  }

  @Override
  public String toString() {
    return "Talk{" +
            "id=" + id +
            ", title='" + title + '\'' +
            ", speakers=" + speakers +
            ", talkType=" + talkType +
            ", start=" + start +
            ", duration=" + duration +
            '}';
  }
}
