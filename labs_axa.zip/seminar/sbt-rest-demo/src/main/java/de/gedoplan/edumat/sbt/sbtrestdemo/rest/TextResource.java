package de.gedoplan.edumat.sbt.sbtrestdemo.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@RestController
@RequestMapping("text")
public class TextResource {

    private static ConcurrentHashMap<Integer, String> textMap = new ConcurrentHashMap<>();
    private static AtomicInteger nextId = new AtomicInteger(1);

    static {
        textMap.put(nextId.getAndIncrement(), "Guten Tag");
        textMap.put(nextId.getAndIncrement(), "Mit freundlichem Gruß");
    }


    @GetMapping
    public Collection<String> getAll() {
        return textMap.values();
    }

    @GetMapping(path = "{id}", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getText(@PathVariable Integer id) {
        String text = textMap.get(id);
        if (text != null) {
            return text;
        }

        throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }
}
