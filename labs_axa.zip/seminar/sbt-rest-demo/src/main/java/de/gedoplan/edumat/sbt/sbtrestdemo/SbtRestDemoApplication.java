package de.gedoplan.edumat.sbt.sbtrestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.annotations.servers.ServerVariable;

@SpringBootApplication
@OpenAPIDefinition(
		info = @Info(
				title = "Spring Boot REST Demo API",
				description = "Demo verschiedener Spring Boot Features",
				version = "1.0.0",
				contact = @Contact(email = "training@gedoplan.de")
		),
		servers = @Server(
				url = "http://{host}:{port}{context}",
				variables = {
						@ServerVariable(name = "host", defaultValue = "localhost"),
						@ServerVariable(name = "port", defaultValue = "8080"),
						@ServerVariable(name = "context", defaultValue = "/")
		})
)
public class SbtRestDemoApplication{

		public static void main(String[] args) {
		SpringApplication.run(SbtRestDemoApplication.class, args);
	}

}
