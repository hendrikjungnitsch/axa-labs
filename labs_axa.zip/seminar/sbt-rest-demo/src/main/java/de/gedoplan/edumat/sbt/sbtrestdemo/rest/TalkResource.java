package de.gedoplan.edumat.sbt.sbtrestdemo.rest;

import de.gedoplan.edumat.sbt.sbtrestdemo.domain.Talk;
import de.gedoplan.edumat.sbt.sbtrestdemo.repository.TalkRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Objects;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
@RequestMapping(value = "talks")
public class TalkResource {
    private final TalkRepository talkRepository;

    public TalkResource(TalkRepository talkRepository) {
        this.talkRepository = talkRepository;
    }

    @Operation(summary = "get all talks")
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Talk> getTalks() {
        return talkRepository.findAll();
    }

    @Operation(summary = "get a talk")
    @ApiResponse(description = "found talk")
    @ApiResponse(responseCode = "404", description = "talk not found")
    @GetMapping(path = "{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public Talk getTalk(@PathVariable Integer id) {
        return talkRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    @Operation(summary = "update talk")
    @ApiResponse(responseCode = "400", description = "id of talk must not be changed")
    @ApiResponse(responseCode = "404", description = "talk not found")
    @PutMapping(path = "{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> putTalk(@PathVariable Integer id, @RequestBody Talk talk) {
        if (!Objects.equals(id, talk.getId())) {
            return ResponseEntity.badRequest()
                    .header("x-message","id of updated object must correspond to path")
                    .build();
        }
        if (talkRepository.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        talkRepository.save(talk);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "create new talk")
    @ApiResponse(responseCode = "400", description = "id of talk must not be pre-set")
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> postTalk(@RequestBody Talk talk, UriComponentsBuilder uriComponentsBuilder) {
        if (Objects.nonNull(talk.getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "id of new entry must not be set");
        }
        talkRepository.save(talk);

        URI uri = uriComponentsBuilder
                .pathSegment("talks", talk.getId().toString())
                .build().toUri();

        return ResponseEntity.created(uri).build();
    }

    @Operation(summary = "delete a talk")
    @DeleteMapping("{id}")
    public void deleteTalk(@PathVariable Integer id) {
        talkRepository.deleteById(id);
    }
}
