package de.gedoplan.edumat.sbt.sbtrestdemo.domain;

public enum TalkType {
  KEYNOTE, SESSION, WORKSHOP;
}
