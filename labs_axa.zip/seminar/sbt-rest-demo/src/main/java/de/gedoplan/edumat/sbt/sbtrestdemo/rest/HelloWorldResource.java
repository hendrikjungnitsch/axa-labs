package de.gedoplan.edumat.sbt.sbtrestdemo.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("hello")
public class HelloWorldResource {

    @GetMapping
    public String helloWorld() {
        return "Hello, world!";
    }


    @GetMapping(path = "mediatype", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getHelloWorld() {
        return "Hello, world!";
    }

    @GetMapping(path = "mediatype", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public String getHelloWorldBinary() {
        return "Hello, binary world!";
    }


    @GetMapping("{first}-{last}")
    public String getGreeting(@PathVariable String first, @PathVariable String last) {
        return "Hello, %s %s!".formatted(first, last);
    }

    @GetMapping("{a}/{b}")
    public String getXyz(@PathVariable int a, @PathVariable int b) {
        return "a=%s, b=%s".formatted(a, b);
    }


    @GetMapping("params")
    public String getXyz(@RequestParam String firstName, @RequestParam String lastName) {
        return "Hello, %s %s!".formatted(firstName, lastName);
    }


    @ResponseStatus(HttpStatus.ACCEPTED)
    @GetMapping("/doNothing")
    public void doNothing() {
        System.out.println("nichtsTun");
    }


    @GetMapping("/exception")
    public void exception() {
        throw new RuntimeException("An error occurred");
    }

    @GetMapping("/notFound")
    public void notFound() {
        throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/conflict")
    public void conflict() {
        throw new IllegalStateException();
    }


    @GetMapping("/responseEntity")
    public ResponseEntity<String> responseEntity() {
        return new ResponseEntity<>("Hello, world!", HttpStatus.OK);
    }

    @GetMapping("/responseHeader")
    public ResponseEntity<String> responseEntityWithHeader() {
        return ResponseEntity.ok()
            .header("Custom-header", "test")
            .body("Hello World");
    }
 }
