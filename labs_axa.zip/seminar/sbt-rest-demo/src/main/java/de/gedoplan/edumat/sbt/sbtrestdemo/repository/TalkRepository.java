package de.gedoplan.edumat.sbt.sbtrestdemo.repository;

import de.gedoplan.edumat.sbt.sbtrestdemo.domain.Talk;
import de.gedoplan.edumat.sbt.sbtrestdemo.domain.TalkType;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Component
public class TalkRepository {

    private static ConcurrentHashMap<Integer, Talk> talks = new ConcurrentHashMap<>();
    private static AtomicInteger nextId = new AtomicInteger(1);

    public TalkRepository() {
        init();
    }

    public void save(Talk talk) {
        if(Objects.isNull(talk.getId())) {
            setId(talk,nextId.getAndIncrement());
        }
        talks.put(talk.getId(),talk);
    }

    public Optional<Talk> findById(Integer id) {
        return Optional.ofNullable(talks.get(id));
    }

    public void deleteById(Integer id) {
        talks.remove(id);
    }

    public List<Talk> findAll() {
        return talks.values().stream().toList();
    }

    private void setId(Talk talk, Integer id) {
        Field field = ReflectionUtils.findField(Talk.class, "id");
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field,talk,id);
    }

    private void init() {
        Stream.of(new Talk("Workshop zu Lambdas und Streams in Java 8", TalkType.WORKSHOP, LocalDateTime.parse("2014-05-12T09:00"), 480, "Angelika Langer", "Klaus Kreft"),
                        new Talk("Power Workshop Java EE", TalkType.WORKSHOP, LocalDateTime.parse("2014-05-12T09:00"), 480, "Dirk Weil"),
                        new Talk("JavaEE (7) Quantum of Code", TalkType.SESSION, LocalDateTime.parse("2014-05-13T09:45"), 75, "Adam Bien"),
                        new Talk("Feige sein!", TalkType.SESSION, LocalDateTime.parse("2014-05-13T15:00"), 60, "Dirk Weil"),
                        new Talk("Hypermedia mit JAX-RS 2.0", TalkType.SESSION, LocalDateTime.parse("2014-05-13T18:00"), 60, "Thilo Frotscher"),
                        new Talk("Eclipse SmartHome", TalkType.SESSION, LocalDateTime.parse("2014-05-14T16:00"), 60, "Thomas Eichstädt-Engelen"),
                        new Talk("Java SE 8 for Tablets, Pis, and Legos", TalkType.SESSION, LocalDateTime.parse("2014-05-14T17:15"), 60, "Stephen Chin"),
                        new Talk("Real Steel - der ultimative Roboterfight!", TalkType.SESSION, LocalDateTime.parse("2014-05-14T20:55"), 120, "Bernhard Löwenstein"))
                .forEach(this::save);
    }
}
