package de.gedoplan.edumat.sbt.sbtrestdemo.rest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.time.Duration;

@RestController
@RequestMapping("/sse")
public class ReactiveResource {

    @GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> getElements() {
        return Flux.interval(Duration.ofSeconds(2)).take(10)
                .map(sequence -> "Element "+sequence);
    }

}
