package de.gedoplan.edumat.sbt.sbtrestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
