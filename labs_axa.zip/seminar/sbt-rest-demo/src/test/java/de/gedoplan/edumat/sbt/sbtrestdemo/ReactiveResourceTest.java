package de.gedoplan.edumat.sbt.sbtrestdemo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.concurrent.TimeUnit;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ReactiveResourceTest {

    @LocalServerPort
    private int port;

    private WebClient client;

    @BeforeEach
    public void init() {
        client = WebClient.create("http://localhost:" + port + "/sse");
    }

    @Test
    public void testSSE() throws InterruptedException {
        Flux<String> events = client.get()
                .retrieve().bodyToFlux(String.class);

        events.subscribe(System.out::println);
        TimeUnit.SECONDS.sleep(25);
    }
}
