package de.gedoplan.edumat.sbt.sbtrestdemo;

import de.gedoplan.edumat.sbt.sbtrestdemo.domain.Talk;
import de.gedoplan.edumat.sbt.sbtrestdemo.domain.TalkType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClient;

import java.util.List;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TalkResourceTest {

    @LocalServerPort
    private int port;
    private RestClient client;

    @BeforeEach
    public void init() {
        client = RestClient.create("http://localhost:"+port+"/talks");
    }

    @Test
    public void testGetTalks() {
        List<Talk> talks = client.get()
                .retrieve().body(new ParameterizedTypeReference<List<Talk>>() {});
        System.out.printf("Found %d talks:\n", talks.size());
        talks.forEach(talk -> System.out.println("  "+talk));
    }

    @Test
    public void testGetTalkById() {
        Talk talk = client.get()
                .uri(ub -> ub.path("/{id}").build(1))
                .retrieve().body(Talk.class);
        System.out.println(talk);
    }

    @Test
    public void testCreateTalk() {
        Talk talk = new Talk("Duck Typing Made Simple", TalkType.SESSION, null, 75, "Donald Duck");

        ResponseEntity<String> response = client.post()
                .contentType(MediaType.APPLICATION_JSON)
                .body(talk)
                .retrieve()
                .toEntity(String.class);

        HttpStatus httpStatus = HttpStatus.resolve(response.getStatusCode().value());
        System.out.printf("Response status: %03d %s\n", httpStatus.value(), httpStatus.getReasonPhrase());
        String message = switch (httpStatus) {
            case CREATED -> "URI: %s\n".formatted(response.getHeaders().getLocation());
            case INTERNAL_SERVER_ERROR -> response.getBody();
            default -> "";
        };
        System.out.println(message);

    }
}
