package de.gedoplan.seminar.sbt.di.demo.service;

import org.springframework.stereotype.Component;

@Component
public class ScopeDemoService2 {

  private final RequestScopedService requestScopedService;

  private final SingletonScopedService singletonScopedService;

  private final PrototypeScopedService dependentScopedService;

  public ScopeDemoService2(RequestScopedService requestScopedService, SingletonScopedService singletonScopedService, PrototypeScopedService dependentScopedService) {
    this.requestScopedService = requestScopedService;
    this.singletonScopedService = singletonScopedService;
    this.dependentScopedService = dependentScopedService;
  }

  public String getScopeInfo() {
    return String.format(
        "Request %02d, Singleton %tT, Prototype %02d",
        this.requestScopedService.getInstanceNumber(),
        this.singletonScopedService.getInstanceCreated(),
        this.dependentScopedService.getInstanceNumber());
  }
}
