package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.PaymentMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/payment")
public class PaymentResource {

    private final Map<String, PaymentMethod> paymentMethods;

    public PaymentResource(List<PaymentMethod> paymentMethods) {
        this.paymentMethods = paymentMethods.stream()
                .collect(Collectors.toMap(PaymentMethod::type, Function.identity()));
    }

    @PostMapping(consumes = MediaType.TEXT_PLAIN_VALUE)
    public String pay(@RequestParam String method, @RequestBody String amount) {
        return Optional.ofNullable(paymentMethods.get(method))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Payment Method"))
                .pay(new BigDecimal(amount));
    }
}
