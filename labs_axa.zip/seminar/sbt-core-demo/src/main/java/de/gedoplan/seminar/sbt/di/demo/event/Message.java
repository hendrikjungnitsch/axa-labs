package de.gedoplan.seminar.sbt.di.demo.event;

public class Message {
  private String text;

  public Message(String text) {
    this.text = text;
  }

  public String getText() {
    return this.text;
  }

  @Override
  public String toString() {
    return "Message [text=" + this.text + "]";
  }
}
