package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.NormalGreetingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloResourceConstructor {

    private final NormalGreetingService normalGreetingService;

    public HelloResourceConstructor(NormalGreetingService normalGreetingService) {
        this.normalGreetingService = normalGreetingService;
    }

    @GetMapping
    public String getHelloWorld() {
        return this.normalGreetingService.getGreeting() + ", this is \"Hello, world\" based on DI via constructor.";
    }
}
