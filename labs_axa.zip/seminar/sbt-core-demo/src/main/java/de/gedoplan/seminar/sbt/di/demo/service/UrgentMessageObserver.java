package de.gedoplan.seminar.sbt.di.demo.service;

import de.gedoplan.seminar.sbt.di.demo.event.UrgentMessage;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class UrgentMessageObserver {
  @Autowired
  Logger logger;

  @EventListener
  @Order(1)
  void processUrgentMessage(UrgentMessage message) {
    this.logger.info("Urgent message received: " + message);
  }
}
