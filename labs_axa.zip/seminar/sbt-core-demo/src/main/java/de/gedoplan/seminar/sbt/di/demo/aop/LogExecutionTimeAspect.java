package de.gedoplan.seminar.sbt.di.demo.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;

@Aspect
@Component
public class LogExecutionTimeAspect {

    @Autowired
    private Logger logger;

    @Around("@annotation(LogExecutionTime)")
    public Object logExecutionTime(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Instant start = Instant.now();
        Object result = proceedingJoinPoint.proceed();
        long time = Duration.between(start, Instant.now()).toMillis();
        logger.info(proceedingJoinPoint.getSignature() + " executed in " + time + "ms");
        return result;
    }
}
