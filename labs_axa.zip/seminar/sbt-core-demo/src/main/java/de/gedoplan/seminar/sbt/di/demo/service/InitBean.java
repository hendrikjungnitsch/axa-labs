package de.gedoplan.seminar.sbt.di.demo.service;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.time.LocalDateTime;

@Component
public class InitBean {

    private String initMessage;

    @Autowired
    private Logger logger;

    @Autowired
    private NormalGreetingService greetingService;

    @PostConstruct
    private void init() {
        initMessage = "Bean initialized at " + LocalDateTime.now() + ". Greeting was: " + greetingService.getGreeting();
        logger.info("init");
    }

    public String getInitMessage() {
        return initMessage;
    }

    @PreDestroy
    private void cleanUp() {
        logger.info("cleanup");
    }


}
