package de.gedoplan.seminar.sbt.di.demo.service;

import java.io.Serializable;

public interface GreetingService extends Serializable {
  public String getGreeting();
}
