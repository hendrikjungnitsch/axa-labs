package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.event.Message;
import de.gedoplan.seminar.sbt.di.demo.event.UrgentMessage;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("messages")
public class MessageResource {

    private final ApplicationEventPublisher publisher;

    public MessageResource(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    @PostMapping
    public void sendMessage(@RequestBody String text) {
        Message message = new Message(text+"; Message of " + LocalDateTime.now());

        this.publisher.publishEvent(message);
    }

    @PostMapping("/urgent")
    public void sendUrgentMessage(@RequestBody String text) {
        Message message = new UrgentMessage(text+"; Urgent message of " + LocalDateTime.now());

        this.publisher.publishEvent(message);
    }
}
