package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.CreditCardService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("creditCard")
public class CreditCardResource {

    private final CreditCardService creditCardService;

    public CreditCardResource(CreditCardService creditCardService) {
        this.creditCardService = creditCardService;
    }

    @GetMapping
    public boolean isCreditCardValid(@RequestParam String number,
                                     @RequestParam String owner,
                                     @RequestParam int validToYear,
                                     @RequestParam int validToMonth,
                                     @RequestParam String check) {
        return creditCardService.isValid(number,owner,validToYear,validToMonth,check);
    }
}
