package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.InitBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("initTime")
public class InitResource {

    private final InitBean initBean;

    public InitResource(InitBean initBean) {
        this.initBean = initBean;
    }

    @GetMapping
    public String getInitTime() {
        return initBean.getInitMessage();
    }
}
