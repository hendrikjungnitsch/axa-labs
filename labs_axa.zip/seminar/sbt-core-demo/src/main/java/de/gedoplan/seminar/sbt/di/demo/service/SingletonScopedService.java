package de.gedoplan.seminar.sbt.di.demo.service;

import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Component
public class SingletonScopedService {
  private LocalDateTime instanceCreated;

  public LocalDateTime getInstanceCreated() {
    return this.instanceCreated;
  }

  @PostConstruct
  public void init() {
    this.instanceCreated = LocalDateTime.now();
  }
}
