package de.gedoplan.seminar.sbt.di.demo.service;

import java.math.BigDecimal;

public interface PaymentMethod {
    public String pay(BigDecimal amount);
    public String type();
}
