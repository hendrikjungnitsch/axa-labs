package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.ScopeDemoService1;
import de.gedoplan.seminar.sbt.di.demo.service.ScopeDemoService2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/scopedemo")
public class ScopeDemoResource {

    private final ScopeDemoService1 scopeDemoService1;

    private final ScopeDemoService2 scopeDemoService2;

    public ScopeDemoResource(ScopeDemoService1 scopeDemoService1, ScopeDemoService2 scopeDemoService2) {
        this.scopeDemoService1 = scopeDemoService1;
        this.scopeDemoService2 = scopeDemoService2;
    }

    @GetMapping
    public String[] getScopeInfo() {
        return new String[] { this.scopeDemoService1.getScopeInfo(), this.scopeDemoService2.getScopeInfo() };
    }
}
