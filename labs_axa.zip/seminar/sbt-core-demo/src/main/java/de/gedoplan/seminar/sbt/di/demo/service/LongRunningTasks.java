package de.gedoplan.seminar.sbt.di.demo.service;

import de.gedoplan.seminar.sbt.di.demo.aop.LogExecutionTime;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@Component
public class LongRunningTasks {

    @LogExecutionTime
    @Async
    public CompletableFuture<String> task1() throws InterruptedException {
        TimeUnit.SECONDS.sleep(5);
        return CompletableFuture.completedFuture("Task1 completed");
    }

    @LogExecutionTime
    @Async
    public CompletableFuture<String> task2() throws InterruptedException {
        TimeUnit.SECONDS.sleep(6);
        return CompletableFuture.completedFuture("Task2 completed");
    }
}
