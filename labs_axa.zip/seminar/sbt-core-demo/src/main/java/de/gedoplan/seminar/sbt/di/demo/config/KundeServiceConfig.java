package de.gedoplan.seminar.sbt.di.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "demo.kunde-service")
public record KundeServiceConfig(String host, Integer port, boolean enableOauth) {}
