package de.gedoplan.seminar.sbt.di.demo.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@ConditionalOnProperty(name = "creditCardService.mock", havingValue = "true")
@Component
public class MockCreditCardService implements CreditCardService {

  @Override
  public boolean isValid(String cardNo, String owner, int validToYear, int validToMonth, String checkNo) {
    if (cardNo.startsWith("34") || cardNo.startsWith("37")) {
      // AMEX
      return cardNo.length() == 15;
    }

    if (cardNo.startsWith("4")) {
      // VISA
      return cardNo.length() == 13 || cardNo.length() == 16;
    }

    if (cardNo.startsWith("51") || cardNo.startsWith("52") || cardNo.startsWith("53") || cardNo.startsWith("54") || cardNo.startsWith("55")) {
      // MC
      return cardNo.length() == 16;
    }

    throw new IllegalArgumentException("Test nur für AMEX, VISA und MC implementiert");
  }
}
