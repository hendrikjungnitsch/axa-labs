package de.gedoplan.seminar.sbt.di.demo.service;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class CreditCardPayment implements PaymentMethod {
    @Override
    public String pay(BigDecimal amount) {
        return "Paid " + amount + " via CreditCard";
    }

    @Override
    public String type() {
        return "creditcard";
    }
}
