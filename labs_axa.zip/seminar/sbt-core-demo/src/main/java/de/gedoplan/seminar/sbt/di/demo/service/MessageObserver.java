package de.gedoplan.seminar.sbt.di.demo.service;

import de.gedoplan.seminar.sbt.di.demo.event.Message;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class MessageObserver {

  @Autowired
  Logger logger;

  @EventListener
  void processMessage(Message message) {
    this.logger.info("Message received: " + message);
  }
}
