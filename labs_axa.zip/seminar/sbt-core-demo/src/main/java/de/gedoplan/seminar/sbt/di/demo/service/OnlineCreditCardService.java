package de.gedoplan.seminar.sbt.di.demo.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@ConditionalOnProperty(name = "creditCardService.mock", havingValue = "false", matchIfMissing = true)
@Component
public class OnlineCreditCardService implements CreditCardService {

  @Override
  public boolean isValid(String cardNo, String owner, int validToYear, int validToMonth, String checkNo) {
    throw new RuntimeException("Not yet implemented");
  }
}
