package de.gedoplan.seminar.sbt.di.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@EnableRetry
@ConfigurationPropertiesScan
@SpringBootApplication
public class SbtCoreDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbtCoreDemoApplication.class, args);
    }

}
