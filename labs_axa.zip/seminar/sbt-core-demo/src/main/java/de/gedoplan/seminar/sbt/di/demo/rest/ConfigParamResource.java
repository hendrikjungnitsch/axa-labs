package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.config.KundeServiceConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("configParams")
public class ConfigParamResource {

    @Value("hello world!")
    private String hello;

    @Value("${demo.hello}")
    private String helloProperty;

    @Value("${Path}")
    private String pathEnv;

    @Value("${some.property:just a default hello}")
    private String helloWithDefault;

    @Autowired
    private KundeServiceConfig kundeServiceConfig;

    @GetMapping
    public Map<String, String> getParams() {
        return Map.of("hello literal", hello,
                "hello property", helloProperty,
                "pathEnv", pathEnv.substring(0, 23),
                "hello with default", helloWithDefault);
    }

    @GetMapping("kundeServiceConfig")
    public KundeServiceConfig getKundeServiceConfig() {
        return kundeServiceConfig;
    }


}
