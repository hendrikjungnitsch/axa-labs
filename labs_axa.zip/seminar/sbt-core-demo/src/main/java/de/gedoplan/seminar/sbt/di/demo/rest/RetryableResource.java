package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.RandomFailureService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.SocketTimeoutException;

@RestController
@RequestMapping("retryable")
public class RetryableResource {

    private final RandomFailureService randomFailureService;

    public RetryableResource(RandomFailureService randomFailureService) {
        this.randomFailureService = randomFailureService;
    }

    @GetMapping
    public void call() throws SocketTimeoutException {
        randomFailureService.callExternalService();
    }
}
