package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.LongRunningTasks;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("longRunningTasks")
public class LongRunningResource {

    private final LongRunningTasks longRunningTasks;

    public LongRunningResource(LongRunningTasks longRunningTasks) {
        this.longRunningTasks = longRunningTasks;
    }

    @GetMapping
    public List<String> runTasks() throws InterruptedException, ExecutionException {
        CompletableFuture<String> future1 = longRunningTasks.task1();
        CompletableFuture<String> future2 = longRunningTasks.task2();
        CompletableFuture.allOf(future1, future2).join();
        return List.of(future1.get(),future2.get());
    }
}
