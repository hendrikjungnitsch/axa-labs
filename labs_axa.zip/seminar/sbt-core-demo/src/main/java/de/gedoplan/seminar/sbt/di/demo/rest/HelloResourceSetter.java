package de.gedoplan.seminar.sbt.di.demo.rest;

import de.gedoplan.seminar.sbt.di.demo.service.NormalGreetingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/helloSetter")
public class HelloResourceSetter {

    private NormalGreetingService normalGreetingService;


    @GetMapping
    public String getHelloWorld() {
        return this.normalGreetingService.getGreeting() + ", this is \"Hello, world\" based on DI via setter.";
    }

    @Autowired
    public void setNormalGreetingService(NormalGreetingService normalGreetingService) {
        this.normalGreetingService = normalGreetingService;
    }
}
