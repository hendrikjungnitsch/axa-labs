package de.gedoplan.seminar.sbt.di.demo.event;

public class UrgentMessage extends Message {

  public UrgentMessage(String text) {
    super(text);
  }

}
