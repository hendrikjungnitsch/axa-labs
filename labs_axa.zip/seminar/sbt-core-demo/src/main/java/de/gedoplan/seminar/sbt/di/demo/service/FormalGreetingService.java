package de.gedoplan.seminar.sbt.di.demo.service;

import de.gedoplan.seminar.sbt.di.demo.annotation.Formal;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//@Formal
//@Component
public class FormalGreetingService implements GreetingService {

  @Override
  public String getGreeting() {
    return "Dear Madams and Sirs";
  }

}
