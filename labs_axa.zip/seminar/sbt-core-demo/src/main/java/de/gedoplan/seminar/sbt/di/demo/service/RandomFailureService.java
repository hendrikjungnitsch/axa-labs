package de.gedoplan.seminar.sbt.di.demo.service;

import org.slf4j.Logger;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.net.SocketTimeoutException;
import java.util.Random;

@Component
public class RandomFailureService {

    private final Logger logger;

    public RandomFailureService(Logger logger) {
        this.logger = logger;
    }

    @Retryable(include = SocketTimeoutException.class, maxAttempts = 3)
    public void callExternalService() throws SocketTimeoutException {
        logger.info("try to call external service");
        if (new Random().nextInt(3) != 1) {
            throw new SocketTimeoutException("Timeout calling service");
        }
        logger.info("completed call to external service");
    }
}
