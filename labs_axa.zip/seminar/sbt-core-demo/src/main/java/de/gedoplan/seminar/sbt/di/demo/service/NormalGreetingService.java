package de.gedoplan.seminar.sbt.di.demo.service;

import de.gedoplan.seminar.sbt.di.demo.aop.LogExecutionTime;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.time.LocalTime;

//@Primary
//@Qualifier("normal")

@Component
public class NormalGreetingService implements GreetingService {

  @Override
  public String getGreeting() {
    int hourOfDay = LocalTime.now().getHour();
    if (hourOfDay < 10) {
      return "Good morning";
    } else if (hourOfDay < 18) {
      return "Good afternoon";
    } else {
      return "Good evening";
    }
  }
}
