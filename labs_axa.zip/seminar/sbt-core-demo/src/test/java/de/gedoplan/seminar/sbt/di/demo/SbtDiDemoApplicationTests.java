package de.gedoplan.seminar.sbt.di.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtDiDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
