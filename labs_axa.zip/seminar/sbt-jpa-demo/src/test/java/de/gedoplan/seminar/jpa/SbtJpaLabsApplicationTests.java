package de.gedoplan.seminar.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtJpaLabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
