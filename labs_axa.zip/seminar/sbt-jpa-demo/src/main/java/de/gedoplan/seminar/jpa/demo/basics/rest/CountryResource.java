package de.gedoplan.seminar.jpa.demo.basics.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import de.gedoplan.seminar.jpa.demo.basics.domain.Continent;
import de.gedoplan.seminar.jpa.demo.basics.domain.Country;
import de.gedoplan.seminar.jpa.demo.basics.repository.CountryRepository;


@RestController
@RequestMapping(value = "demo/basics/countries", produces = MediaType.APPLICATION_JSON_VALUE)
public class CountryResource {
	
	private static Logger log = LoggerFactory.getLogger(CityResource.class);

  // Some test data
  private Country testCountryCA = new Country("CA", "Canada", "1", null, 34_482_779, Continent.NORTH_AMERICA, false);
  private Country testCountryCN = new Country("CN", "China", "86", null, 1_331_460_000, Continent.ASIA, false);
  private Country testCountryDE = new Country("DE", "Germany", "49", "D", 81_879_976, Continent.EUROPE, false);
  private Country testCountryIT = new Country("IT", "Italy", "39", "I", 60_221_210, Continent.EUROPE, false);
  private Country testCountryUS = new Country("US", "United States of America", "1", null, 305_548_183, Continent.NORTH_AMERICA, false);
  private Country testCountryVN = new Country("VN", "Vietnam", "84", null, 87_840_000, Continent.ASIA, false);
  private Country testCountryYU = new Country("YU", "Yugoslavia", null, null, 0, Continent.EUROPE, true);
  private List<Country> testCountries = List.of(this.testCountryCA, this.testCountryCN, this.testCountryDE, this.testCountryIT, this.testCountryUS, this.testCountryVN, this.testCountryYU );

  @Autowired
  CountryRepository countryRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  public void insert() {
    log.debug("----- insert -----");

    this.countryRepository.saveAll(testCountries);

    log.debug("Inserted: " + testCountries);
  }

  /**
   * Demo: Find entries by id.
   */
  @GetMapping("findById")
  public void findById() {
    log.debug("----- findById -----");

    log.debug("IT: " + this.countryRepository.findById("IT"));
    log.debug("xx: " + this.countryRepository.findById("xx"));
  }

  /**
   * Demo: Update some entry.
   */
  @Transactional
  @GetMapping("update")
  public void update() {
    log.debug("----- update -----");

    Country country = this.countryRepository.findById("IT").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    long populationOld = country.getPopulation();
    long populationNew = populationOld + 2;
    country.setPopulation(populationNew);

    log.debug("IT-population: " + populationOld + " -> " + populationNew);
  }

  /**
   * Demo: Delete an entry.
   */
  @GetMapping("delete")
  public void delete() {
    log.debug("----- delete -----");

    this.countryRepository.deleteById("CA");

    log.debug("CA removed");
  }

  /**
   * Demo: Find all entries.
   */
  @GetMapping("findAll")
  public List<Country> findAll() {
    log.info("----- findAll -----");

    List<Country> countries = this.countryRepository.findAll();
    countries.stream().map(Country::toString).forEach(log::debug);
    return countries;
  }

  /**
   * Demo: Find entries by car code (using numbered parameter).
   */
  @GetMapping("findByCarCode")
  public List<Country> findByCarCode() {
    log.debug("----- findByCarCode -----");

    List<Country> countries = this.countryRepository.findByCarCode("D");
    countries.stream().map(Country::toString).forEach(log::debug);
    return countries;
  }

  /**
   * Demo: Find entries by phone prefix (using named parameter).
   */
  @GetMapping("findByPhonePrefix")
  public List<Country> findByPhonePrefix() {
    log.debug("----- findByPhonePrefix -----");

    List<Country> countries = this.countryRepository.findByPhonePrefix("49");
    countries.stream().map(Country::toString).forEach(log::debug);
    return countries;
  }
  
  @GetMapping("countCountriesInEurope")
  public long countCountriesInEurope() {
	  log.debug("----- countCountriesInEurope -----");

	  return this.countryRepository.countCountriesInEurope();
  }

  @GetMapping("byNameIgnoreCase")
  public List<Country> findByNameIgnoreCase() {
	  log.debug("----- findByNameIgnoreCase -----");

    Country country = new Country(null, "ItAly", null, null,0, null, false);

    ExampleMatcher matcher = ExampleMatcher.matchingAll()
        .withIgnorePaths("population")    // primitive int cannot be null, 0 would be used as search value
        .withIgnoreCase();
    Example<Country> example = Example.of(country, matcher);
    List<Country> countries = countryRepository.findAll(example);
    countries.stream().map(Country::toString).forEach(log::debug);
    return countries;
  }
}
