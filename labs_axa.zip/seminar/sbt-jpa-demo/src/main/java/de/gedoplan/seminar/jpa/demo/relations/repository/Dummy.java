package de.gedoplan.seminar.jpa.demo.relations.repository;

import de.gedoplan.seminar.jpa.demo.relations.domain.Album;
import de.gedoplan.seminar.jpa.demo.relations.domain.Artist;
import de.gedoplan.seminar.jpa.demo.relations.domain.MailAddress;
import de.gedoplan.seminar.jpa.demo.relations.domain.Person;
import jakarta.persistence.EntityManager;

public class Dummy {

  EntityManager entityManager;

  void dummy() {

    Person person = this.entityManager.find(Person.class, 0);

    for (MailAddress mailAddress : person.getMailAddresses()) {
      System.out.println(mailAddress);
    }

  }

  void dummy2() {
    Album album = this.entityManager.find(Album.class, 0); // Some non-transient entity
    Artist artist = this.entityManager.find(Artist.class, 0); // Some managed entity

    // Achtung: Wirkt nur mit Transaktion
    album.getArtists().add(artist);

    // Falls bidirektional
    artist.getAlbums().add(album);

  }
}
