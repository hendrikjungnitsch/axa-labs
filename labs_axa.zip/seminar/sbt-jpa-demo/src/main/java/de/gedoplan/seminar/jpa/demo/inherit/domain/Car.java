package de.gedoplan.seminar.jpa.demo.inherit.domain;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@DiscriminatorValue(value = "Car")
@Table(name = Car.TABLE_NAME)
public class Car extends Vehicle {
  public static final String TABLE_NAME = "JPA_CAR";

  private int noOfDoors;

  protected Car() {
  }

  public Car(String name, int noOfDoors) {
    super(name);
    this.noOfDoors = noOfDoors;
  }

  public int getNoOfDoors() {
    return this.noOfDoors;
  }
}
