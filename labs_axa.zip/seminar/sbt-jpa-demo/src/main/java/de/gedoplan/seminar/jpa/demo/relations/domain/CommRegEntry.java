package de.gedoplan.seminar.jpa.demo.relations.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = CommRegEntry.TABLE_NAME)
public class CommRegEntry {
  public static final String TABLE_NAME = "JPA_COMMREGENTRY";

  @Id
  private Integer id;

  private String legalForm;

  public Integer getId() {
    return this.id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getLegalForm() {
    return this.legalForm;
  }

  public void setLegalForm(String legalForm) {
    this.legalForm = legalForm;
  }

}
