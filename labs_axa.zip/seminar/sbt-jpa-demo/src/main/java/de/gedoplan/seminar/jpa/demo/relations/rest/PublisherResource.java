package de.gedoplan.seminar.jpa.demo.relations.rest;

import java.util.List;
import java.util.Set;

import jakarta.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.gedoplan.seminar.jpa.demo.relations.domain.Book;
import de.gedoplan.seminar.jpa.demo.relations.domain.MailAddress;
import de.gedoplan.seminar.jpa.demo.relations.domain.Person;
import de.gedoplan.seminar.jpa.demo.relations.domain.Publisher;
import de.gedoplan.seminar.jpa.demo.relations.repository.BookRepository;
import de.gedoplan.seminar.jpa.demo.relations.repository.PublisherRepository;


@RestController
@RequestMapping(value = "demo/relations/publishers", produces = MediaType.APPLICATION_JSON_VALUE)
public class PublisherResource {
	
	private static Logger log = LoggerFactory.getLogger(PublisherResource.class);

  // Test data
  private Publisher testPublisher1 = new Publisher("O'Melly Publishing");
  private Publisher testPublisher2 = new Publisher("Expert Press");
  private Publisher testPublisher3 = new Publisher("Books reloaded");
  private List<Publisher> testPublishers = List.of(this.testPublisher1, this.testPublisher2, this.testPublisher3);

  private Person testPerson1 = new Person("Brummer", "Bernd", new MailAddress("brummer", "gmx.de"));
  private Person testPerson2 = new Person("Wacker", "Willi", new MailAddress("wacker", "web.de"));
  private List<Person> testPersons = List.of( this.testPerson1, this.testPerson2 );

  private Book testBook11 = new Book("Better JPA Programs", "12345-6789-0", 340);
  private Book testBook12 = new Book("Inside JPA", "54321-9876-X", 265);
  private Book testBook13 = new Book("Java and Databases", "11111-2222-6", 850);
  private Book testBook21 = new Book("Java for Beginners", "564534-432-2", 735);
  private Book testBook22 = new Book("Java vs. C#", "333333-123-0", 145);
  private Book testBook23 = new Book("Optimizing Java Programs", "765432-767-8", 230);
  private Book testBook30 = new Book("Is there a World after Java?", null, 1);
  private List<Book> testBooks = List.of(this.testBook11, this.testBook12, this.testBook13, this.testBook21, this.testBook22, this.testBook23, this.testBook30 );

  private List<Book> testBooksOfPublisher1 = List.of(this.testBook11, this.testBook12, this.testBook13);
  private List<Book> testBooksOfPublisher2 = List.of( this.testBook21, this.testBook22, this.testBook23 );

  {
    for (Book book : this.testBooksOfPublisher1) {
      book.changePublisher(this.testPublisher1);
      book.getAuthors().add(this.testPerson1);
    }

    for (Book book : this.testBooksOfPublisher2) {
      book.changePublisher(this.testPublisher2);
      book.getAuthors().add(this.testPerson2);
    }

    this.testBook13.getAuthors().add(this.testPerson2);
  }

  @Autowired
  PublisherRepository publisherRepository;

  @Autowired
  BookRepository bookRepository;

  @Autowired
  EntityManager personRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  @Transactional
  public void insert() {
    log.info("----- test_01_insertData -----");

    publisherRepository.saveAll(this.testPublishers);
    log.debug("Inserted: " + this.testPublishers);
    
    testPersons.forEach(personRepository::persist);
    
    log.debug("Inserted: " + this.testPersons);
    
    bookRepository.saveAll(this.testBooks);    

    log.debug("Inserted: " + this.testBooks);

  }

  /**
   * Demo: Find all entries and print them in the log including their books.
   * <p>
   * In order to watch the SQL statements triggered by this code, switch on statement logging:
   * - for Hibernate add spring.jpa.show-sql=true in application.yaml
   */
  @GetMapping("showAll")
  public List<Publisher> showAll() {
    log.info("----- showAll -----");

    List<Publisher> publishers = publisherRepository.findAll();
    publishers.forEach(p -> {
      log.debug(p.toString());
      p.getBooks().forEach(b -> log.debug("  " + b));
    });
    return publishers;
  }

  @GetMapping("showAllEager")
  public Set<Publisher> showAllEager() {
    log.info("----- showAllEager -----");

    Set<Publisher> publishers = publisherRepository.fetchAllWithBooks();
    publishers.forEach(p -> {
      log.debug(p.toString());
      p.getBooks().forEach(b -> log.debug("  " + b));
    });
    return publishers;
  }


  @GetMapping("/booksByPublisherName/{name}")
  public Set<Book> showBooks(@PathVariable String name) {
    log.info("----- booksByPublisherName -----");

    Set<Book> books = bookRepository.findByPublisher_Name(name);
    books.forEach(b -> log.debug(b.toString()));
    return books;
  }

}
