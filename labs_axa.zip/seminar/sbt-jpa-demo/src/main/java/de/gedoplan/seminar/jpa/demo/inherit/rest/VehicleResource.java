package de.gedoplan.seminar.jpa.demo.inherit.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.gedoplan.seminar.jpa.demo.inherit.domain.Car;
import de.gedoplan.seminar.jpa.demo.inherit.domain.Ship;
import de.gedoplan.seminar.jpa.demo.inherit.domain.Vehicle;
import de.gedoplan.seminar.jpa.demo.inherit.repository.VehicleRepository;

/**
 * Demo REST endpoints for Vehicle and derived classes.
 * <p>
 * In order to watch the SQL statements triggered by this code, switch on
 * statement logging: - for EclipseLink set persistence.xml property
 * eclipselink.logging.level to FINE - for Hibernate configure server logging
 * and set the log level for category org.hibernate.SQL to DEBUG
 */
@RestController
@RequestMapping(value = "demo/inherit/vehicles", produces = MediaType.APPLICATION_JSON_VALUE)
public class VehicleResource {

	private static Logger log = LoggerFactory.getLogger(VehicleResource.class);
	
	// Some test data
	private Car testCar1 = new Car("Peugeot 407SW", 5);
	private Car testCar2 = new Car("Fiat Panda", 3);

	private Ship testShip1 = new Ship("AIDAluna", 69200);
	private Ship testShip2 = new Ship("Disney Fantasy", 130000);

	private List<Vehicle> testVehicles = List.of(this.testCar1, this.testCar2, this.testShip1, this.testShip2);

	@Autowired
	VehicleRepository vehicleRepository;

	/**
	 * Demo: Insert test data.
	 */
	@GetMapping("insert")
	public void insert() {
		log.debug("----- insert -----");

		this.vehicleRepository.saveAll(testVehicles);
		log.debug("Inserted: " + testVehicles);
	}

	/**
	 * Demo: Find all entries (polymorphic query).
	 */
	@GetMapping("findAll")
	public List<Vehicle> findAll() {
		log.info("----- findAll -----");

		List<Vehicle> vehicles = this.vehicleRepository.findAll();
		vehicles.forEach(v -> log.debug(v.toString()));
		return vehicles;
	}

	/**
	 * Demo: Find all ships.
	 */
	@GetMapping("findAllShips")
	public List<Ship> findAllShips() {
		log.info("----- findAllShips -----");

		List<Ship> ships = this.vehicleRepository.findAllShips();
		ships.forEach(v -> log.debug(v.toString()));
		return ships;
	}

}
