package de.gedoplan.seminar.jpa.demo.relations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.demo.relations.domain.Book;

import java.util.Set;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

  // entspricht der Query
  // @Query("select b from Book b where b.publisher.name = :name")
  public Set<Book> findByPublisher_Name(String name);
}
