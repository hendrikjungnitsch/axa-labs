package de.gedoplan.seminar.jpa.demo.inherit.domain;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = CarPart.TABLE_NAME)
public class CarPart extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_CARPART";

  private String name;

  @ManyToOne
  private Car car;

  public String getName() {
    return this.name;
  }

  public void setCar(Car car) {
    this.car = car;
  }
}
