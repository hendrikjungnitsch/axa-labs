package de.gedoplan.seminar.jpa.demo.inherit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import de.gedoplan.seminar.jpa.demo.inherit.domain.Ship;
import de.gedoplan.seminar.jpa.demo.inherit.domain.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer>{
	
  @Query("select s from Ship s")
  public List<Ship> findAllShips();


}
