package de.gedoplan.seminar.jpa.demo.relations.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.gedoplan.seminar.jpa.demo.common.StringIdEntity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = Basket.TABLE_NAME)
public class Basket extends StringIdEntity {
  public static final String TABLE_NAME = "JPA_BASKET";

  private LocalDateTime created = LocalDateTime.now();

  @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
  @JoinColumn(name = "BASKET_ID")
  @OrderColumn(name = "ITEMS_ORDER")
  // @OrderBy("name")
  private List<Item> items = new ArrayList<>();

  public Basket(String id, Item... items) {
    super(id);
    this.items = Arrays.asList(items);
  }

  protected Basket() {
  }

  public LocalDateTime getCreated() {
    return this.created;
  }

  public List<Item> getItems() {
    return this.items;
  }

}
