package de.gedoplan.seminar.jpa.demo.relations.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import de.gedoplan.seminar.jpa.demo.relations.domain.Basket;
import de.gedoplan.seminar.jpa.demo.relations.domain.Item;
import de.gedoplan.seminar.jpa.demo.relations.repository.BasketRepository;


@RestController
@RequestMapping(value = "demo/relations/baskets", produces = MediaType.APPLICATION_JSON_VALUE)
public class BasketResource {

  private static Logger log = LoggerFactory.getLogger(BasketResource.class);

  @Autowired
  BasketRepository basketRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  public void insert() {
    log.info("----- insert -----");

    this.basketRepository.save(new Basket("demo-basket", new Item("wine"), new Item("water"), new Item("juice")));
  }

  /**
   * Demo: Remove all baskets
   */
  @DeleteMapping
  public void removeAll() {
    this.basketRepository.deleteAll();
  }

  /**
   * Demo: Reduce basket by one item.
   */
  @GetMapping("reduce")
  @Transactional
  public void reduce() {
    log.info("----- reduce -----");

    Basket basket = this.basketRepository.findById("demo-basket").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    if (!basket.getItems().isEmpty()) {
      basket.getItems().remove(0);
    }
  }

  /**
   * Demo: Find all entries and log them including their items.
   */
  @GetMapping
  public List<Basket> showAll() {
    log.info("----- showAll -----");

    List<Basket> baskets = this.basketRepository.findAll();
    baskets.forEach(p -> {
      log.debug(p.toString());
      p.getItems().forEach(i -> log.debug("  " + i));
    });
    return baskets;
  }
}
