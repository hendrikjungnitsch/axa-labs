package de.gedoplan.seminar.jpa.demo.relations.domain;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.NamedAttributeNode;
import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.NamedSubgraph;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;

@Entity
@Table(name = Publisher.TABLE_NAME)
@NamedEntityGraph(name = "Publisher_books", attributeNodes = @NamedAttributeNode(value = "books"))
@NamedEntityGraph(name = "Publisher_booksAndAuthors", attributeNodes = @NamedAttributeNode(value = "books", subgraph = "Book_authors"), subgraphs = @NamedSubgraph(name = "Book_authors", attributeNodes = @NamedAttributeNode("authors")))
public class Publisher extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_PUBLISHER";
  public static final String CATEGORIES_TABLE_NAME = "JPA_PUBLISHER_CATEGORIES";

  public static final String COUNTRY_FK_NAME = "COUNTRY_ISO_CODE";

  private String name;

  @JsonIgnoreProperties("publisher")
  @OneToMany(mappedBy = "publisher", fetch = FetchType.LAZY)
  private Set<Book> books;

  protected Publisher() {
  }

  public Publisher(String name) {
    this.name = name;

    this.books = new HashSet<>();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Set<Book> getBooks() {
    return this.books;
    // return Collections.unmodifiableSet(this.books);
  }

  void addBook(Book book) {
    this.books.add(book);
  }

  void removeBook(Book book) {
    this.books.remove(book);
  }

  @Override
  public String toString() {
    return "Publisher{" +
            "name='" + name + '\'' +
            '}';
  }
}
