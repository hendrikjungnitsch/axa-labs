package de.gedoplan.seminar.jpa.demo.basics.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.demo.basics.domain.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {

  public List<Country> findByCarCode(String carCode);

  // @Query("select c from Country c where c.phonePrefix = :phonePrefix")
  public List<Country> findByPhonePrefix(/*@Param("phonePrefix")*/ String phonePrefix);

  public List<Country> findByName(String countryName);
  
  @Query("select count(c) from Country c where c.continent = de.gedoplan.seminar.jpa.demo.basics.domain.Continent.EUROPE")
  public long countCountriesInEurope();

}
