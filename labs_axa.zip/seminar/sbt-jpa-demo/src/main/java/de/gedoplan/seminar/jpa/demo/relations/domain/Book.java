package de.gedoplan.seminar.jpa.demo.relations.domain;

import java.util.HashSet;
import java.util.Set;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = Book.TABLE_NAME)
public class Book extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_BOOK";
  public static final String AUTHORS_TABLE_NAME = "JPA_BOOK_AUTHORS";

  private String name;
  private String isbn;
  private int pages;

  @JsonIgnoreProperties("books")
  @ManyToOne
  // @JoinTable(name = "JPA_BOOK_PUBLISHER", joinColumns = { @JoinColumn(name = "book_id") })
  private Publisher publisher;

  @ManyToMany
  @JoinTable(name = AUTHORS_TABLE_NAME, joinColumns = @JoinColumn(name = "book_id"), inverseJoinColumns = @JoinColumn(name = "author_id"))
  private Set<Person> authors;

  protected Book() {
  }

  public Book(String name, String isbn, int pages) {
    this.name = name;
    this.isbn = isbn;
    this.pages = pages;

    this.authors = new HashSet<>();
  }

  public String getName() {
    return this.name;
  }

  public String getIsbn() {
    return this.isbn;
  }

  public int getPages() {
    return this.pages;
  }

  public Publisher getPublisher() {
    return this.publisher;
  }

  public void changePublisher(Publisher publisher) {
    if (this.publisher != null) {
      this.publisher.removeBook(this);
    }

    this.publisher = publisher;

    if (this.publisher != null) {
      this.publisher.addBook(this);
    }
  }

  public Set<Person> getAuthors() {
    return this.authors;
  }

  @Override
  public String toString() {
    return "Book{" +
            "name='" + name + '\'' +
            ", isbn='" + isbn + '\'' +
            ", pages=" + pages +
            '}';
  }
}
