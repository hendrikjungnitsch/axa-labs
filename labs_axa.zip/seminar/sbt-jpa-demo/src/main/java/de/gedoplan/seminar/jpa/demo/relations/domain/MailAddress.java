package de.gedoplan.seminar.jpa.demo.relations.domain;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = MailAddress.TABLE_NAME)
public class MailAddress extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_MAILADDRESS";

  private String userId;
  private String domain;

  public MailAddress(String userId, String domain) {
    this.userId = userId;
    this.domain = domain;
  }

  protected MailAddress() {
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getDomain() {
    return this.domain;
  }

  public void setDomain(String domain) {
    this.domain = domain;
  }
}
