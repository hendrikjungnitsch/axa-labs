package de.gedoplan.seminar.jpa.demo.basics.domain;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.Table;

import de.gedoplan.seminar.jpa.demo.converter.YesNoConverter;

@Entity
@Table(name = Employee.TABLE_NAME)
public class Employee
{
  public static final String TABLE_NAME = "JPA_EMPLOYEE";
  public static final String NOTES_TABLE_NAME = "JPA_EMPLOYEE_NOTES";
  public static final String PHONES_TABLE_NAME = "JPA_EMPLOYEE_PHONES";

  @Id
  private Integer id;
  private String name;

  @Embedded
  
  private Address address;

  // @AttributeOverride(name = "zipCode", column = @Column(name = "HOME_ZIPCODE"))
  // @AttributeOverride(name = "town", column = @Column(name = "HOME_TOWN"))
  // @AttributeOverride(name = "street", column = @Column(name = "HOME_STREET"))
  // private Address homeAddress;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = Employee.NOTES_TABLE_NAME, joinColumns = @JoinColumn(name = "EMPLOYEE_ID"))
  @Column(name = "NOTE")
  private List<String> notes;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = Employee.PHONES_TABLE_NAME, joinColumns = @JoinColumn(name = "EMPLOYEE_ID"))
  @MapKeyColumn(name = "PHONE_TYPE")
  @Column(name = "PHONE")
  private Map<String, String> phones;

  private double salary;

  protected Employee() {
  }

  public Employee(Integer id, String name, Address address, List<String> notes, Map<String, String> phones, double salary) {
    this.id = id;
    this.name = name;
    this.notes = notes;
    this.phones = phones;
    this.salary = salary;
    this.address = address;
  }

  // Remaining methods can be omitted when using SingleIdEntity as base class

  public Integer getId() {
    return this.id;
  }

  public String getName() {
    return this.name;
  }

  public Address getAddress() {
    return this.address;
  }

  public List<String> getNotes() {
    return this.notes;
  }

  public Map<String, String> getPhones() {
    return this.phones;
  }

  public double getSalary() {
    return this.salary;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id);
  }

  @Override
  public String toString() {
    return "Employee [id=" + this.id + ", name=" + this.name + ", address=" + this.address + ", notes=" + this.notes + ", phones=" + this.phones + ", salary=" + this.salary + "]";
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Employee other = (Employee) obj;
    return Objects.equals(this.id, other.id);
  }

}
