package de.gedoplan.seminar.jpa.demo.basics.service;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.gedoplan.seminar.jpa.demo.basics.domain.City;
import de.gedoplan.seminar.jpa.demo.basics.repository.CityRepository;

/**
 * Checker for some expectations about entity object equality.
 * <p>
 * Try the following scenarios:
 *
 * <ol>
 * <li>Use <code>@GeneratedValue</code> and <code>Integer</code> for {@link City#id}. <br/>
 * Do not implement <code>hashcode</code> and <code>equals</code>.</li>
 * <li>Same as 1., but use a standard implementation of <code>hashcode</code> and <code>equals</code> using only the <code>id</code> field.</li>
 * <li>Same as 2., but modify <code>equals</code>, returning <code>false</code>, if <code>id</code> is unset.</li>
 * <li>Use <code>UUID</code> for {@link City#id}. <br/>
 * Do not use <code>@GeneratedValue</code>. <br/>
 * Implement <code>hashcode</code> and <code>equals</code> as in 2.</li>
 * </ol>
 *
 * Only the last version meets every expectation!
 */
@Service
public class CityExpectationService {

	private static Logger log = LoggerFactory.getLogger(CityExpectationService.class);

  @Autowired
  CityRepository cityRepository;

  public void check() {
    try {
      /*
       * Expectation a)
       * If we fill a set with multiple transient objects, we expect that the set contains them all in the end.
       */
      Set<City> cities = new HashSet<>();
      City london = new City("London", 8982000, 1572);
      cities.add(london);
      cities.add(new City("Madrid", 3223000, 604));
      cities.add(new City("Paris", 2161000, 105));

      log.debug(String.format("a) Set accepts multiple transient objects: %s", cities.size() > 1));

      /*
       * Expectation b)
       * If we iterate over a set of transient objects and persist the all, we expect that the set still contains them afterwards.
       */
      cityRepository.saveAll(cities);

      log.debug(String.format("b) Hash sets remain intact after persisting their entries: %s", cities.contains(london)));

      /*
       * Expectation c)
       * If we have a detached object from a former database operation, we expect it to be equal to the same db entry re-read some time later.
       */
      log.debug(String.format("c) Objects remain equal in different entity managers: %s", this.cityRepository.findAll().contains(london)));
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
