package de.gedoplan.seminar.jpa.demo.basics.domain;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = SupermarketEmbeddedId.TABLE_NAME)
public class SupermarketEmbeddedId {
  public static final String TABLE_NAME = "JPA_SUPERMARKET";

  @EmbeddedId
  private BranchId id;

  private String name;

  protected SupermarketEmbeddedId() {
  }

  public SupermarketEmbeddedId(int companyId, int branchNo, String name) {
    this.id = new BranchId(companyId, branchNo);
    this.name = name;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public BranchId getId() {
    return this.id;
  }

}
