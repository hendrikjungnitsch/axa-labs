package de.gedoplan.seminar.jpa.demo.relations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.demo.relations.domain.Publisher;

import java.util.Set;

@Repository
public interface PublisherRepository extends JpaRepository<Publisher, Integer> {

  @Query("select p from Publisher p left join fetch p.books")
  public Set<Publisher> fetchAllWithBooks();
}
