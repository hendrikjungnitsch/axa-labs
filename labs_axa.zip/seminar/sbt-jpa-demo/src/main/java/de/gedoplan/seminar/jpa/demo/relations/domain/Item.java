package de.gedoplan.seminar.jpa.demo.relations.domain;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = Item.TABLE_NAME)
public class Item extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_ITEM";

  private String name;

  protected Item() {
  }

  public Item(String name) {
    this.name = name;
  }

  public String getName() {
    return this.name;
  }
}
