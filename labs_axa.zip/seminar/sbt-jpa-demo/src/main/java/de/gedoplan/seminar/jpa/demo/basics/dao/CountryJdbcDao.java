package de.gedoplan.seminar.jpa.demo.basics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import jakarta.persistence.PersistenceException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.gedoplan.seminar.jpa.demo.basics.domain.Country;

@Component
public class CountryJdbcDao {

  // Use default datasource for demo
  @Autowired
  DataSource dataSource;

  public void persist(Country country) {

    try (
        Connection connection = this.dataSource.getConnection();
        PreparedStatement statement = connection.prepareStatement("insert into JPA_COUNTRY(ISO_CODE,NAME,PHONE_PREFIX,POPULATION,EXPIRED) values (?,?,?,?,?)")) {
      statement.setString(1, country.getIsoCode());
      statement.setString(2, country.getName());
      statement.setString(3, country.getPhonePrefix());
      statement.setLong(4, country.getPopulation());
      statement.setBoolean(5, country.isExpired());
      statement.executeUpdate();

    } catch (SQLException e) {
      throw new PersistenceException(e);
    }
  }

  public Optional<Country> findById(String isoCode) {

    try (
        Connection connection = this.dataSource.getConnection();
        PreparedStatement statement = connection.prepareStatement("select ISO_CODE,NAME,PHONE_PREFIX,POPULATION,EXPIRED from JPA_COUNTRY where ISO_CODE=?")) {
      statement.setString(1, isoCode);
      ResultSet resultSet = statement.executeQuery();

      if (!resultSet.next()) {
        return Optional.empty();
      }

      String id = resultSet.getString(1);
      String name = resultSet.getString(2);
      String phonePrefix = resultSet.getString(3);
      long population = resultSet.getLong(4);
      boolean expired = resultSet.getBoolean(5);
      Country country = new Country(id, name, phonePrefix, null, population, null, expired);
      return Optional.of(country);

    } catch (SQLException e) {
      throw new PersistenceException(e);
    }
  }
}
