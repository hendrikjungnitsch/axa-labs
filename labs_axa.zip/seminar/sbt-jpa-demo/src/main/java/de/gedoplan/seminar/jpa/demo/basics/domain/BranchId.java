package de.gedoplan.seminar.jpa.demo.basics.domain;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Embeddable;

@Embeddable
public class BranchId implements Serializable {
  private int companyId;
  private int branchNo;

  public BranchId() {
  }

  public BranchId(int companyId, int branchNo) {
    this.companyId = companyId;
    this.branchNo = branchNo;
  }

  public int getCompanyId() {
    return this.companyId;
  }

  public void setCompanyId(int companyId) {
    this.companyId = companyId;
  }

  public int getBranchId() {
    return this.branchNo;
  }

  public void setBranchId(int branchNo) {
    this.branchNo = branchNo;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.branchNo, this.companyId);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    BranchId other = (BranchId) obj;
    return this.branchNo == other.branchNo && this.companyId == other.companyId;
  }

  @Override
  public String toString() {
    return "BranchId [companyId=" + this.companyId + ", branchNo=" + this.branchNo + "]";
  }

}
