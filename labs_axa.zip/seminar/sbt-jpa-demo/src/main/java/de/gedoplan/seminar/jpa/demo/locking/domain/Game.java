package de.gedoplan.seminar.jpa.demo.locking.domain;

import de.gedoplan.seminar.jpa.demo.common.StringIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

@Entity
@Table(name = Game.TABLE_NAME)
public class Game extends StringIdEntity {
  public static final String TABLE_NAME = "JPA_GAME";

  private String name;
  private int minPlayers;

  private int maxPlayers;

  @Version
  private long version;

  protected Game() {
  }

  public Game(String id, String name, int minPlayers, int maxPlayers) {
    super(id);
    this.name = name;
    this.minPlayers = minPlayers;
    this.maxPlayers = maxPlayers;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getMinPlayers() {
    return this.minPlayers;
  }

  public void setMinPlayers(int minPlayers) {
    this.minPlayers = minPlayers;
  }

  public int getMaxPlayers() {
    return this.maxPlayers;
  }

  public void setMaxPlayers(int maxPlayers) {
    this.maxPlayers = maxPlayers;
  }

  @Override public String toString() {
    return "Game {" +
        "name='" + name + '\'' +
        ", minPlayers = " + minPlayers +
        ", maxPlayers = " + maxPlayers +
        ", version = " + version +
        '}';
  }
}
