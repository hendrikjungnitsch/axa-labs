package de.gedoplan.seminar.jpa.demo.locking.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import de.gedoplan.seminar.jpa.demo.locking.domain.Game;
import de.gedoplan.seminar.jpa.demo.locking.repository.GameRepository;

@RestController
@RequestMapping(value = "demo/locking/games", produces = MediaType.APPLICATION_JSON_VALUE)
public class GameResource {
	
	private static Logger log = LoggerFactory.getLogger(GameResource.class);

  // Some test data
  private Game testGame1 = new Game("mensch", "Mensch ärgere dich nicht", 2, 4);
  private Game testGame2 = new Game("schach", "Schach", 2, 2);
  private Game testGame3 = new Game("scyard", "Scotland Yard", 2, 4);

  private List<Game> testGames = List.of(this.testGame1, this.testGame2, this.testGame3);


  @Autowired
  GameRepository gameRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  public void insert() {
    log.debug("----- insert -----");


    this.gameRepository.saveAll(testGames);

    log.debug("Inserted: " + testGames);
  }

  /**
   * Demo: Update some attributes ("User A").
   */
  @GetMapping("userAoptimistic")
  @Transactional
  public void userA() {
    log.debug("----- userAoptimistic -----");

    Game game = this.gameRepository.findById("mensch").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

    log.debug("A: Read " + game);

    log.debug("A: Waiting");

    try {
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      // ignore
    }

    game.setName("A-"+Math.random()*100+"-Mensch-ärgere-dich-nicht");
    game.setMinPlayers(1);
    log.debug("A: Set  " + game);
  }

  /**
   * Demo: Update some attributes ("User B").
   */
  @GetMapping("userBoptimistic")
  @Transactional
  public void userB() {
    log.debug("----- userBoptimistic -----");

    Game game = this.gameRepository.findById("mensch").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

    log.debug("B: Read " + game);

    game.setName("B-"+Math.random()*100+"-Mensch-ärgere-dich-nicht");
    game.setMaxPlayers(6);
    log.debug("B: Set  " + game);

  }/**
   * Demo Pessimistic Locking: Update some attributes ("User A").
   */
  @GetMapping("userApessimistic")
  @Transactional
  public void userApessimistic() {
    log.debug("----- userApessimistic -----");

    Game game = this.gameRepository.findByIdPessimistic("mensch").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

    log.debug("A: Read pessimistic" + game);

    log.debug("A: Waiting");

    try {
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      // ignore
    }

    game.setName("A-"+Math.random()*100+"-Mensch-ärgere-dich-nicht");
    game.setMinPlayers(1);
    log.debug("A: Set  " + game);
  }

  /**
   * Demo Pessimistic Locking: Update some attributes ("User B").
   */
  @GetMapping("userBpessimistic")
  @Transactional
  public void userBpessimistic() {
    log.debug("----- userBpessimistic -----");

    Game game = this.gameRepository.findByIdPessimistic("mensch").orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

    log.debug("B: Read " + game);

    game.setName("B-"+Math.random()*100+"-Mensch-ärgere-dich-nicht");
    game.setMaxPlayers(6);
    log.debug("B: Set  " + game);
  }
}
