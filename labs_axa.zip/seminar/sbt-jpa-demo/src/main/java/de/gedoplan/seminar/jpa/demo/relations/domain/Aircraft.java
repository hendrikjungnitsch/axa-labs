package de.gedoplan.seminar.jpa.demo.relations.domain;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = Aircraft.TABLE_NAME)
public class Aircraft extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_AIRCRAFT";

  private String maker;
  private String type;
  private String serialNo;

  public String getMaker() {
    return this.maker;
  }

  public void setMaker(String maker) {
    this.maker = maker;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getSerialNo() {
    return this.serialNo;
  }

  public void setSerialNo(String serialNo) {
    this.serialNo = serialNo;
  }
}
