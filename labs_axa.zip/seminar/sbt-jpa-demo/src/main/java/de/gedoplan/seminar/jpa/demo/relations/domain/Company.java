package de.gedoplan.seminar.jpa.demo.relations.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = Company.TABLE_NAME)
public class Company {
  public static final String TABLE_NAME = "JPA_COMPANY";

  @Id
  private Integer id;
  private String name;

  @OneToOne
  // @PrimaryKeyJoinColumn
  private CommRegEntry commRegEntry;

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public CommRegEntry getCommRegEntry() {
    return this.commRegEntry;
  }

  public void setCommRegEntry(CommRegEntry commRegEntry) {
    this.commRegEntry = commRegEntry;
  }

  public Integer getId() {
    return this.id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

}
