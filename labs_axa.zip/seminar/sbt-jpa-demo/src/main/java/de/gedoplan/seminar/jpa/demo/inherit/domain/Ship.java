package de.gedoplan.seminar.jpa.demo.inherit.domain;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@DiscriminatorValue(value = "Ship")
@Table(name = Ship.TABLE_NAME)
public class Ship extends Vehicle {
  public static final String TABLE_NAME = "JPA_SHIP";

  private double tonnage;

  protected Ship() {
  }

  public Ship(String name, int tonnage) {
    super(name);
    this.tonnage = tonnage;
  }

  public double getTonnage() {
    return this.tonnage;
  }
}
