package de.gedoplan.seminar.jpa.demo.relations.rest;

import de.gedoplan.seminar.jpa.demo.relations.domain.Item;
import de.gedoplan.seminar.jpa.demo.relations.repository.ItemRepository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "demo/relations/items", produces = MediaType.APPLICATION_JSON_VALUE)
public class ItemResource {
  private static Logger log = LoggerFactory.getLogger(ItemResource.class);

  @Autowired
  ItemRepository itemRepository;

  /**
   * Demo: Find all items.
   */
  @GetMapping
  public List<Item> showAll() {
    log.info("----- showAll -----");

    return this.itemRepository.findAll();
  }

  /**
   * Demo: Remove all items
   */
  @DeleteMapping
  public void removeAll() {
    this.itemRepository.deleteAll();
  }

}
