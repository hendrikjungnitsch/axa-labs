package de.gedoplan.seminar.jpa.demo.relations.domain;

import java.util.HashSet;
import java.util.Set;

import de.gedoplan.seminar.jpa.demo.common.StringIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = Album.TABLE_NAME)
public class Album extends StringIdEntity {
  public static final String TABLE_NAME = "JPA_ALBUM";
  public static final String ARTISTS_TABLE_NAME = "JPA_ALBUM_ARTIST";

  private String name;

  @ManyToMany
  @JoinTable(name = ARTISTS_TABLE_NAME, joinColumns = @JoinColumn(name = "ALBUM_ID"), inverseJoinColumns = @JoinColumn(name = "ARTIST_ID"))
  private Set<Artist> artists;

  public Album(String id, String name) {
    super(id);
    this.name = name;
    this.artists = new HashSet<>();
  }


  public String getName() {
    return this.name;
  }

  public Set<Artist> getArtists() {
    return this.artists;
  }

  protected Album() {
  }
}
