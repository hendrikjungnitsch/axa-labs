package de.gedoplan.seminar.jpa.demo.basics.domain;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = City.TABLE_NAME)
public class City // extends GeneratedIntegerIdEntity
{

  public static final String TABLE_NAME = "JPA_CITY";

  // Id must be removed when using GeneratedIntegerIdEntity as base class

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cityGeneratorSequence")
  // @SequenceGenerator(name = "cityGeneratorSequence", sequenceName = "JPA_CITY_SEQUENCE", allocationSize = 100)
  // @GeneratedValue(strategy = GenerationType.TABLE, generator = "cityGeneratorTable")
  // @TableGenerator(name = "cityGeneratorTable", table = "JPA_CITY_GEN", pkColumnName = "GENERATOR", pkColumnValue = "City", valueColumnName = "ID", allocationSize = 100)
  // @GeneratedValue(strategy = GenerationType.UUID)
  private Integer id;
  // private UUID id;

  private String name;

  private int population;

  private int area;

  public City(String name, int population, int area) {
    this.name = name;
    this.population = population;
    this.area = area;

    // this.id = UUID.randomUUID();
  }

  public String getName() {
    return this.name;
  }

  public int getPopulation() {
    return this.population;
  }

  public int getArea() {
    return this.area;
  }

  protected City() {
  }

  // Remaining methods can be omitted when using GeneratedIntegerIdEntity as base class

  public Object getId() {
    return this.id;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    // if (this.id == null) {
    // return false;
    // }
    City other = (City) obj;
    return Objects.equals(this.id, other.id);
  }

  @Override
  public String toString() {
    return "City [id=" + this.id + ", name=" + this.name + ", population=" + this.population + ", area=" + this.area + "]";
  }

}
