package de.gedoplan.seminar.jpa.demo.basics.domain;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@IdClass(BranchId.class)
@Table(name = SupermarketCompositeId.TABLE_NAME)
public class SupermarketCompositeId {
  public static final String TABLE_NAME = "JPA_SUPERMARKET";

  @Id
  private int companyId;

  @Id
  private int branchNo;

  private String name;

  protected SupermarketCompositeId() {
  }

  public SupermarketCompositeId(int companyId, int branchNo, String name) {
    this.companyId = companyId;
    this.branchNo = branchNo;
    this.name = name;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getCompanyId() {
    return this.companyId;
  }

  public int getBranchNo() {
    return this.branchNo;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.branchNo, this.companyId);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    SupermarketCompositeId other = (SupermarketCompositeId) obj;
    return this.branchNo == other.branchNo && this.companyId == other.companyId;
  }

  @Override
  public String toString() {
    return "SupermarketCompositeId [companyId=" + this.companyId + ", branchNo=" + this.branchNo + ", name=" + this.name + "]";
  }

}
