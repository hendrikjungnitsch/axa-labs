package de.gedoplan.seminar.jpa.demo.basics.domain;

import java.util.Objects;

import jakarta.persistence.Embeddable;

@Embeddable
public class Address {
  private String zipCode;
  private String town;
  private String street;
  private Boolean pob;

  protected Address() {
  }

  public Address(String zipCode, String town, String street, Boolean pob) {
    this.zipCode = zipCode;
    this.town = town;
    this.street = street;
    this.pob = pob;
  }

  public String getZipCode() {
    return this.zipCode;
  }

  public String getTown() {
    return this.town;
  }

  public String getStreet() {
    return this.street;
  }

  public Boolean isPob() {
    return this.pob;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.pob, this.street, this.town, this.zipCode);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Address other = (Address) obj;
    return Objects.equals(this.pob, other.pob) && Objects.equals(this.street, other.street) && Objects.equals(this.town, other.town) && Objects.equals(this.zipCode, other.zipCode);
  }

  @Override
  public String toString() {
    return "Address [zipCode=" + this.zipCode + ", town=" + this.town + ", street=" + this.street + ", isPob=" + this.pob + "]";
  }

}
