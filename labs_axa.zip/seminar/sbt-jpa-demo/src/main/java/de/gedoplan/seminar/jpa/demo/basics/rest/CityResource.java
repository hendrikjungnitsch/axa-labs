package de.gedoplan.seminar.jpa.demo.basics.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.gedoplan.seminar.jpa.demo.basics.domain.City;
import de.gedoplan.seminar.jpa.demo.basics.repository.CityRepository;
import de.gedoplan.seminar.jpa.demo.basics.service.CityExpectationService;

@RestController
@RequestMapping(value = "demo/basics/cities", produces = MediaType.APPLICATION_JSON_VALUE)
public class CityResource {
	
  private static Logger log = LoggerFactory.getLogger(CityResource.class);

  // Some test data
  private City testCity1 = new City("Berlin", 3500000, 892);
  private City testCity2 = new City("Bielefeld", 325000, 258);
  private City testCity3 = new City("Dortmund", 580000, 280);
  private City testCity4 = new City("Mannheim", 315000, 145);
  private City testCity5 = new City("Stuttgart", 600000, 207);
  private List<City> testCities = List.of(this.testCity1, this.testCity2, this.testCity3, this.testCity4, this.testCity5 );


  @Autowired
  CityRepository cityRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  public void insert() {
      this.cityRepository.saveAll(this.testCities);
  }

  /**
   * Demo: Find all entries.
   */
  @GetMapping("findAll")
  public List<City> findAll() {
    log.info("----- findAll -----");

    List<City> cities = this.cityRepository.findAll();
    cities.stream().map(City::toString).forEach(log::debug);
    return cities;
  }

  @Autowired
  CityExpectationService cityExpectationService;

  @GetMapping("expectations")
  public void checkExpectations() {
    this.cityExpectationService.check();
  }

}
