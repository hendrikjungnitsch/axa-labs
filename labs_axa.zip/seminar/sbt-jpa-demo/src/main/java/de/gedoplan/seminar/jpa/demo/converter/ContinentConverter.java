package de.gedoplan.seminar.jpa.demo.converter;

import de.gedoplan.seminar.jpa.demo.basics.domain.Continent;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(/* autoApply = true */)
public class ContinentConverter implements AttributeConverter<Continent, String> {

  @Override
  public String convertToDatabaseColumn(Continent attribute) {
    return attribute == null ? null : attribute.getIsoCode();
  }

  @Override
  public Continent convertToEntityAttribute(String dbData) {
    return dbData == null ? null : Continent.forIsoCode(dbData);
  }
}
