package de.gedoplan.seminar.jpa.demo.relations.domain;

import java.util.HashSet;
import java.util.Set;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = Artist.TABLE_NAME)
public class Artist extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_ARTIST";

  private String name;

  @ManyToMany(mappedBy = "artists")
  private Set<Album> albums;

  public Artist(String name) {
    this.name = name;
    this.albums = new HashSet<>();
  }

  public String getName() {
    return this.name;
  }

  public Set<Album> getAlbums() {
    return this.albums;
  }

  protected Artist() {
  }
}
