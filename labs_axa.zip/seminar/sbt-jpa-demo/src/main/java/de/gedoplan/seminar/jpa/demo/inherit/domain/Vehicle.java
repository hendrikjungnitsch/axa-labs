package de.gedoplan.seminar.jpa.demo.inherit.domain;

import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DTYPE", discriminatorType = DiscriminatorType.STRING)
// @Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
// @Inheritance(strategy = InheritanceType.JOINED)
@Table(name = Vehicle.TABLE_NAME)
public abstract class Vehicle extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_VEHICLE";

  private String name;

  protected Vehicle() {
  }

  public Vehicle(String name) {
    this.name = name;
  }

  public String getName() {
    return this.name;
  }

}
