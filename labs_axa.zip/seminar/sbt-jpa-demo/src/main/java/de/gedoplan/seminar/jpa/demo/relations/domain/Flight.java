package de.gedoplan.seminar.jpa.demo.relations.domain;

import de.gedoplan.seminar.jpa.demo.common.GeneratedIntegerIdEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = Flight.TABLE_NAME)
public class Flight extends GeneratedIntegerIdEntity {
  public static final String TABLE_NAME = "JPA_FLIGHT";

  private String carrier;
  private int flightNo;

  @ManyToOne
  // @JoinColumn(name = "PLANE_ID", foreignKey = @ForeignKey(ConstraintMode.CONSTRAINT))
  // @JoinTable(name = "JPA_F_A", joinColumns = { @JoinColumn(name = "F_ID") }, inverseJoinColumns = { @JoinColumn(name = "A_ID") })
  private Aircraft aircraft;

  public String getCarrier() {
    return this.carrier;
  }

  public void setCarrier(String carrier) {
    this.carrier = carrier;
  }

  public int getFlightNo() {
    return this.flightNo;
  }

  public void setFlightNo(int flightNo) {
    this.flightNo = flightNo;
  }

  public Aircraft getAircraft() {
    return this.aircraft;
  }

  public void setAircraft(Aircraft aircraft) {
    this.aircraft = aircraft;
  }
}
