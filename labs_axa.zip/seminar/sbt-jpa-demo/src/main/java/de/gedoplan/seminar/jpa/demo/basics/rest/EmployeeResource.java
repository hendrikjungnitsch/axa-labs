package de.gedoplan.seminar.jpa.demo.basics.rest;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.gedoplan.seminar.jpa.demo.basics.domain.Address;
import de.gedoplan.seminar.jpa.demo.basics.domain.Employee;
import de.gedoplan.seminar.jpa.demo.basics.repository.EmployeeRepository;



@RestController
@RequestMapping(value = "demo/basics/employees", produces = MediaType.APPLICATION_JSON_VALUE)
public class EmployeeResource {
	
	private static Logger log = LoggerFactory.getLogger(CityResource.class);
	
  private Address testAddress = new Address("33605", "Bielefeld", "Stieghorster Str. 60", false);
  private Employee testEmployee1 = new Employee(
      1, "Harry Hirsch", this.testAddress,
      List.of("15 years at GEDOPLAN on Jun 15, 2012", "First aider"),
      Map.of("WORK", "+49 521 20889-77", "MOBILE", "+49 170 22334455"),
      3500);
  private Employee testEmployee2 = new Employee(
      2, "Willi Wacker", this.testAddress,
      List.of("Certified Scrum master"),
      Map.of("WORK", "+49 521 20889-88", "MOBILE", "+49 171 55443322"),
      2500);
  private List<Employee> testEmployees = List.of( this.testEmployee1, this.testEmployee2 );


  @Autowired
  EmployeeRepository employeeRepository;

  /**
   * Demo: Insert test data.
   */
  @GetMapping("insert")
  public void insert() {
    log.debug("----- insert -----");
    this.employeeRepository.saveAll(testEmployees);
  }

  /**
   * Demo: Find all entries.
   */
  @GetMapping("findAll")
  public List<Employee> findAll() {
    log.info("----- findAll -----");

    List<Employee> employees = this.employeeRepository.findAll();
    employees.stream().map(Employee::toString).forEach(log::debug);
    return employees;
  }
}
