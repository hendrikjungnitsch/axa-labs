package de.gedoplan.seminar.jpa.demo.locking.repository;

import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import de.gedoplan.seminar.jpa.demo.locking.domain.Game;

import java.util.Optional;

import jakarta.persistence.LockModeType;

@Repository
public interface GameRepository extends JpaRepository<Game, String> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
//  @QueryHints({@QueryHint(name = "jakarta.persistence.lock.timeout", value = "3000")})
  @Query("select g from Game g where g.id = :id")
  public Optional<Game> findByIdPessimistic(String id);

}
