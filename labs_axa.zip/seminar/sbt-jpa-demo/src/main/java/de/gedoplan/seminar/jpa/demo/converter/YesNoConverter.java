package de.gedoplan.seminar.jpa.demo.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter
public class YesNoConverter implements AttributeConverter<Boolean, String> {

  @Override
  public String convertToDatabaseColumn(Boolean attribute) {
    return attribute == null ? null : attribute ? "yes" : "no";
  }

  @Override
  public Boolean convertToEntityAttribute(String dbData) {
    return dbData == null ? null : dbData.equalsIgnoreCase("yes");
  }
}
